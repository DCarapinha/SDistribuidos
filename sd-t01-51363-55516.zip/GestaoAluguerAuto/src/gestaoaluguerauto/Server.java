package gestaoaluguerauto;

/**
 *
 * @author dc982
 */
public class Server {
    public static void main(String args[]) {
	
	try {            
            // criar um Objeto Remoto
	    GestaoAluguerAuto obj = new GestaoAluguerAutoImpl();
                        
	    // usar o Registry local (mesma máquina) e porto regPort
            //java.rmi.registry.LocateRegistry.createRegistry(regPort);  
	    
            java.rmi.registry.Registry registry = java.rmi.registry.LocateRegistry.getRegistry();

	    registry.bind("aluguer", obj);
            
	    System.out.println("RMI object bound to service in registry");
            System.out.println("servidor pronto");
	} 
	catch (Exception e) {
	    e.printStackTrace();
	}
    }
}
