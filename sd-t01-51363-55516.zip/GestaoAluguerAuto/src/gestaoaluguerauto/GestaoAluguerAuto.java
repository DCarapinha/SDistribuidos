package gestaoaluguerauto;

/**
 *
 * @author dc982
 */
public interface GestaoAluguerAuto extends java.rmi.Remote{
    
    public String registarCliente(String nome, int idade, int bi) throws java.rmi.RemoteException;
    
    public String registarVeiculo(String modelo, String tipo, String matricula, String localizacao, String estado) throws java.rmi.RemoteException;
    
    public String registarAluguer(String matricula, int bi, int valor, String dataInicio, String dataFim, String localizacao) throws java.rmi.RemoteException;
    
    public String listarVeiculosDisponiveis(String localizacao, String tipo) throws java.rmi.RemoteException;
    
    public String listarLocalizacaoDeVeiculos() throws java.rmi.RemoteException;
        
    public String listarHistoricoDeVeiculo(String matricula) throws java.rmi.RemoteException;
    
    public String listarVeiculosPorEstadoAdmin() throws java.rmi.RemoteException;
    
    public String aprovarVeiculo(String matricula) throws java.rmi.RemoteException;
}
