package gestaoaluguerauto;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author dc982
 */
public class Client {
    public static void main(String args[]){
	BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        int op;
        
	try {
            GestaoAluguerAuto aluguer = (GestaoAluguerAuto) java.rmi.Naming.lookup("/aluguer");
            do{
                System.out.println("\n ------------------------------------------------------------------------------------------ ");
                System.out.println("| 0 - Sair                                                                                 |");
                System.out.println("| 1 - Registar Cliente                                                                     |");
                System.out.println("| 2 - Registar Veiculo                                                                     |");
                System.out.println("| 3 - Registar Aluguer                                                                     |");
                System.out.println("| 4 - Listar Veiculos Disponiveis                                                          |");
                System.out.println("| 5 - Listar Localizacao de Veiculos Alugados                                              |");
                System.out.println("| 6 - Listar Historico De Um Veiculo                                                       |");
                System.out.println(" ------------------------------------------------------------------------------------------ \n");
                op = Integer.parseInt(input.readLine());
                
                String nome, modelo, tipo, matricula, localizacao, estado, dataInicio, dataFim, ret;
                int telefone, bi, valor;
                switch(op){
                    case 1:
                        System.out.println("\n -------------------------- Registar Cliente ---------------------------- ");

                        System.out.print("  Nome:\n\t");
                        nome = input.readLine();
                        System.out.print("  Bi:\n\t");
                        bi = Integer.parseInt(input.readLine());
                        System.out.print("  Telefone:\n\t");
                        telefone = Integer.parseInt(input.readLine());

                        ret = aluguer.registarCliente(nome, bi, telefone);
                        if(!ret.equals("")) System.out.println("\n" + ret);

                        System.out.println(" ------------------------------------------------------------------------ ");
                        break;
                    case 2:
                        System.out.println("\n -------------------------- Registar Veiculo ---------------------------- ");

                        System.out.print("  Modelo:\n\t");
                        modelo = input.readLine();
                        System.out.print("  Tipo:\n\t");
                        tipo = input.readLine();
                        System.out.print("  Matricula:\n\t");
                        matricula = input.readLine();
                        System.out.print("  Localização:\n\t");
                        localizacao = input.readLine();
                        System.out.print("  Estado (disponivel, alugado, manutencao):\n\t");
                        estado = input.readLine();

                        ret = aluguer.registarVeiculo(modelo, tipo, matricula, localizacao, estado);
                        if(!ret.equals("")) System.out.println("\n" + ret);

                        System.out.println(" ------------------------------------------------------------------------ ");
                        break;
                    case 3:
                        System.out.println("\n -------------------------- Registar Aluguer ---------------------------- ");

                        System.out.print("  Matricula:\n\t");
                        matricula = input.readLine();
                        System.out.print("  Bi:\n\t");
                        bi = Integer.parseInt(input.readLine());
                        System.out.print("  Valor:\n\t");
                        valor = Integer.parseInt(input.readLine());
                        System.out.print("  Data Inicio (dd-MM-aaaa):\n\t");
                        dataInicio = input.readLine();
                        System.out.print("  Data Fim (dd-MM-aaaa):\n\t");
                        dataFim = input.readLine();
                        System.out.print("  Localizacao:\n\t");
                        localizacao = input.readLine();

                        ret = aluguer.registarAluguer(matricula, bi, valor, dataInicio, dataFim, localizacao);
                        if(!ret.equals("")) System.out.println("\n" + ret);

                        System.out.println(" ------------------------------------------------------------------------ ");
                        break;
                    case 4:
                        System.out.println("\n ---------------------------- Listar Veiculos ---------------------------- ");

                        System.out.print("  Localizacao:\n\t");
                        localizacao = input.readLine();
                        System.out.print("  Tipo:\n\t");
                        tipo = input.readLine();
                        
                        ret = aluguer.listarVeiculosDisponiveis(localizacao, tipo);
                        if(!ret.equals("")) System.out.println("\n" + ret);

                        System.out.println(" ------------------------------------------------------------------------- ");
                        break;
                    case 5:
                        System.out.println("\n ------------------------ Listar Localização -------------------------- ");

                        ret = aluguer.listarLocalizacaoDeVeiculos();
                        if(!ret.equals("")) System.out.println("\n" + ret);

                        System.out.println(" ---------------------------------------------------------------------- ");
                        break;
                    case 6:
                        System.out.println("\n ---------------------------- Listar Historico ---------------------------- ");

                        System.out.print("  Matricula:\n\t");
                        matricula = input.readLine();

                        ret = aluguer.listarHistoricoDeVeiculo(matricula);
                        if(!ret.equals("")) System.out.println("\n" + ret);

                        System.out.println(" -------------------------------------------------------------------------- ");
                        break;
                    case 0:
                    default:
                        break;
                }
            } while(op!= 0);
            input.close();
	} 
	catch (Exception e) {
            System.out.println("Error in Client.main(): " + e.getMessage());
	}
    }    
}
