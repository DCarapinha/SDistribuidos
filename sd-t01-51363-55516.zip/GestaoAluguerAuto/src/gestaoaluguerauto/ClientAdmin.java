package gestaoaluguerauto;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 *
 * @author dc982
 */
public class ClientAdmin {
    public static void main(String args[]){
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        int op;
	try {
            GestaoAluguerAuto aluguer = (GestaoAluguerAuto) java.rmi.Naming.lookup("/aluguer");
            do{
                System.out.println("\n ------------------------------------------------------------------------------------------ ");
                System.out.println("| 0 - Sair                                                                                 |");
                System.out.println("| 1 - Listar Veiculos Por Estado Administrativo                                            |");
                System.out.println("| 2 - Aprovar Um Veiculo                                                                   |");
                System.out.println(" ------------------------------------------------------------------------------------------ \n");
                op = Integer.parseInt(input.readLine());
                
                String matricula, ret;
                
                switch(op){
                    case 1:
                        System.out.println("\n --------------- Listar Veiculos Por Estado Administrativo -------------- ");

                        ret = aluguer.listarVeiculosPorEstadoAdmin();
                        if(!ret.equals("")) System.out.println("\n" + ret);

                        System.out.println(" ------------------------------------------------------------------------ ");
                        break;
                    case 2:
                        System.out.println("\n ------------------------- Aprovar Um Veiculo --------------------------- ");
                        System.out.print("  Matricula:\n\t");
                        matricula = input.readLine();

                        ret = aluguer.aprovarVeiculo(matricula);
                        if(!ret.equals("")) System.out.println("\n" + ret);

                        System.out.println(" ------------------------------------------------------------------------ ");
                        break;
                    case 0:
                    default:
                        break;
                }
            } while(op!= 0);
            input.close();
	} 
	catch (Exception e) {
	    e.printStackTrace();
	}
    }  
}
