package gestaoaluguerauto;

import java.io.*;
import java.util.*;
import java.rmi.server.UnicastRemoteObject;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import sd.PostgresConnector;

/**
 *
 * @author dc982
 */


/**
 * ESTADO DE VEICULO:       disponivel | alugado | manutencao
 * ESTADO ADMINISTRATIVO:   aprovado | não aprovado
 */

public class GestaoAluguerAutoImpl extends UnicastRemoteObject implements GestaoAluguerAuto, java.io.Serializable{    
    public GestaoAluguerAutoImpl() throws java.rmi.RemoteException, Exception {
        super();
    }
    
    @Override
    public String registarCliente(String nome, int bi, int telefone) throws java.rmi.RemoteException{
        String host = "", name = "", user = "", pw = "";
        try{
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();

            // load a properties file
            prop.load(input);
            host = prop.getProperty("dbhost");
            name = prop.getProperty("dbname");
            user = prop.getProperty("dbuser");
            pw = prop.getProperty("dbpassword");
            
            PostgresConnector pc = new PostgresConnector(host, name, user, pw);

            // estabelecer a ligacao à bd
            pc.connect();
            Statement stmt = pc.getStatement();
            stmt.executeUpdate("INSERT INTO cliente VALUES ('" + nome + "'," + bi + "," + telefone + ");");
            
            input.close();
            pc.disconnect();
            stmt.close();
        }
        catch (Exception e) {
            return e.getMessage();
        }
        return "";
    }
    
    @Override
    public String registarVeiculo(String modelo, String tipo, String matricula, String localizacao, String estado) throws java.rmi.RemoteException{
        String host = "", name = "", user = "", pw = "";
        try{
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();

            // load a properties file
            prop.load(input);
            host = prop.getProperty("dbhost");
            name = prop.getProperty("dbname");
            user = prop.getProperty("dbuser");
            pw = prop.getProperty("dbpassword");
            
            PostgresConnector pc = new PostgresConnector(host, name, user, pw);

            // estabelecer a ligacao à bd
            pc.connect();
            Statement stmt = pc.getStatement();
            
            stmt.executeUpdate("INSERT INTO veiculo VALUES ('" + modelo + "','" + tipo + "','" + matricula + 
                    "','" + localizacao + "','" + estado + "', 'não aprovado');");
            
            input.close();
            pc.disconnect();
            stmt.close();
        }
        catch(Exception e){
            return e.getMessage();
        }
        return "";
    }
    
    @Override
    public String registarAluguer(String matricula, int bi, int valor, String dataInicio, String dataFim, String localizacao) throws java.rmi.RemoteException{
        String host = "", name = "", user = "", pw = "";
        try{
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();

            // load a properties file
            prop.load(input);
            host = prop.getProperty("dbhost");
            name = prop.getProperty("dbname");
            user = prop.getProperty("dbuser");
            pw = prop.getProperty("dbpassword");
            
            PostgresConnector pc = new PostgresConnector(host, name, user, pw);

            // estabelecer a ligacao à bd
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res;
            String estado = "", estadoadm = "";
            
            this.atualizarEstados();
            
            res = stmt.executeQuery("SELECT estado, estadoadm FROM veiculo WHERE matricula='" + matricula + "';");
            while(res.next()){
                estado = res.getString("estado");
                estadoadm = res.getString("estadoadm");
            }
            if(!estado.equals("disponivel"))
                return "Veiculo não está disponivel";
            if(!estadoadm.equals("aprovado"))
                return "Veiculo não está aprovado";
            
            
            res = stmt.executeQuery("SELECT data_inicio, data_fim FROM aluguer WHERE matricula='" + matricula + "';");
            
            SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
            Date dateInicio = new Date(formatter.parse(dataInicio).getTime());
            Date dateFim = new Date(formatter.parse(dataFim).getTime());
            
            while(res.next()){
                Date dataInicioRes = res.getDate("data_inicio");
                Date dataFimRes = res.getDate("data_fim");
                
                // Verifica existencia de sobreposicao de datas de aluguer entre data do aluguer atual com datas ja registadas
                if(dateInicio.after(dataInicioRes) && dateFim.before(dataFimRes) ||
                    dateInicio.before(dataInicioRes) && dateFim.after(dataInicioRes) && dateFim.before(dataFimRes) ||
                    dateInicio.after(dataInicioRes) && dateInicio.before(dataFimRes) && dateFim.after(dataFimRes) ||
                    dateInicio.before(dataInicioRes) && dateFim.after(dataFimRes)){
                    return "Veiculo já alugado entre as datas: " + dataInicioRes + ", " + dataFimRes;
                }
            }
            
            stmt.executeUpdate("INSERT INTO aluguer VALUES ('" + matricula + "'," + bi + "," + valor + ",'" + 
                    dataInicio + "','" + dataFim + "','" + localizacao + "');");
            
            this.atualizarEstados();
            
            input.close();
            stmt.close();
            pc.disconnect();
        }
        catch(Exception e){
            return e.getMessage();
        }
        return "";
    }
    
    @Override
    public String listarVeiculosDisponiveis(String localizacao, String tipo) throws java.rmi.RemoteException{
        String host = "", name = "", user = "", pw = "";
        String resultados = "";
        try{
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();

            // load a properties file
            prop.load(input);
            host = prop.getProperty("dbhost");
            name = prop.getProperty("dbname");
            user = prop.getProperty("dbuser");
            pw = prop.getProperty("dbpassword");
            
            PostgresConnector pc = new PostgresConnector(host, name, user, pw);

            // estabelecer a ligacao à bd
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res;
            
            this.atualizarEstados();
            
            if(localizacao.equals("") && tipo.equals(""))
                res = stmt.executeQuery("SELECT * FROM veiculo WHERE estadoadm='aprovado' AND estado='disponivel'");
            else if(!localizacao.equals("") && tipo.equals(""))
                res = stmt.executeQuery("SELECT * FROM veiculo WHERE estadoadm='aprovado' AND estado='disponivel' AND localizacao='"+localizacao+"'");
            else if(localizacao.equals("") && !tipo.equals(""))
                res = stmt.executeQuery("SELECT * FROM veiculo WHERE estadoadm='aprovado' AND estado='disponivel' AND tipo='"+tipo+"'");
            else
                res = stmt.executeQuery("SELECT * FROM veiculo WHERE estadoadm='aprovado' AND estado='disponivel' AND localizacao='"+localizacao+"' AND tipo='"+tipo+"'");
            
            while(res.next()){
                String modeloRes = res.getString("modelo");
                String tipoRes = res.getString("tipo");
                String matriculaRes = res.getString("matricula");
                String localizacaoRes = res.getString("localizacao");
                resultados = resultados.concat("  " + tipoRes + " | " + modeloRes + " | " + matriculaRes + " | " + localizacaoRes + "\n");
            }
            input.close();
            pc.disconnect();
            stmt.close();
            res.close();
        }
        catch(Exception e){
            return e.getMessage();
        }
        return resultados;
    }
    
    @Override
    public String listarLocalizacaoDeVeiculos() throws java.rmi.RemoteException{
        String host = "", name = "", user = "", pw = "";
        String resultados = "";
        try{
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();

            // load a properties file
            prop.load(input);
            host = prop.getProperty("dbhost");
            name = prop.getProperty("dbname");
            user = prop.getProperty("dbuser");
            pw = prop.getProperty("dbpassword");
            
            PostgresConnector pc = new PostgresConnector(host, name, user, pw);

            // estabelecer a ligacao à bd
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res;
            res = stmt.executeQuery("SELECT matricula, localizacao FROM veiculo WHERE estado='alugado';");
            while(res.next()){
                String matriculaRes = res.getString("matricula");
                String localizacaoRes = res.getString("localizacao");
                resultados = resultados.concat("  " + matriculaRes + " | " + localizacaoRes + "\n");
            }
            
            input.close();
            pc.disconnect();
            stmt.close();
            res.close();
        }
        catch(Exception e){
            return e.getMessage();
        }
        return resultados;
    }
    
    @Override
    public String listarHistoricoDeVeiculo(String matricula) throws java.rmi.RemoteException{
        String host = "", name = "", user = "", pw = "";
        String resultados = "";
        try{
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();

            // load a properties file
            prop.load(input);
            host = prop.getProperty("dbhost");
            name = prop.getProperty("dbname");
            user = prop.getProperty("dbuser");
            pw = prop.getProperty("dbpassword");
            
            PostgresConnector pc = new PostgresConnector(host, name, user, pw);

            // estabelecer a ligacao à bd
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res;
            
            res = stmt.executeQuery("SELECT veiculo.matricula, aluguer.localizacao, valor, data_inicio, data_fim FROM veiculo, aluguer "
                    + "WHERE veiculo.matricula=aluguer.matricula AND veiculo.matricula='" + matricula + "';");
            while(res.next()){
                String matriculaRes = res.getString("matricula");
                String localizacaoRes = res.getString("localizacao");
                int valorRes = res.getInt("valor");
                String dataInicioRes = res.getString("data_inicio");
                String dataFimRes = res.getString("data_fim");
                resultados = resultados.concat("  " + matriculaRes + " | " + localizacaoRes + "  |  " + 
                        valorRes + "  |  " + dataInicioRes + "  |  " + dataFimRes + "\n");
            }
            
            input.close();
            pc.disconnect();
            stmt.close();
        }
        catch(Exception e){
            return e.getMessage();
        }
        return resultados;
    }
    
    @Override
    public String listarVeiculosPorEstadoAdmin() throws java.rmi.RemoteException{
        String host = "", name = "", user = "", pw = "";
        String resultados = "";
        try{
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();

            // load a properties file
            prop.load(input);
            host = prop.getProperty("dbhost");
            name = prop.getProperty("dbname");
            user = prop.getProperty("dbuser");
            pw = prop.getProperty("dbpassword");
            
            PostgresConnector pc = new PostgresConnector(host, name, user, pw);

            // estabelecer a ligacao à bd
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res;
            
            res = stmt.executeQuery("SELECT matricula, tipo, modelo, estado, estadoadm FROM veiculo ORDER BY estadoadm;");
            while(res.next()){
                String matriculaRes = res.getString("matricula");
                String modeloRes = res.getString("modelo");
                String tipoRes = res.getString("tipo");
                String estadoRes = res.getString("estado");
                String estadoAdmRes = res.getString("estadoadm");
                resultados = resultados.concat("  " + matriculaRes + " | " + modeloRes + "  |  " + 
                        tipoRes + "  |  " + estadoRes + "  |  " + estadoAdmRes + "\n");
            }
            input.close();
            pc.disconnect();
            stmt.close();
            res.close();
        }
        catch(Exception e){
            return e.getMessage();
        }
        
        return resultados;
    }
    
    @Override
    public String aprovarVeiculo(String matricula) throws java.rmi.RemoteException{
        String host = "", name = "", user = "", pw = "";
        String resultados = "";
        
        try{
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();

            // load a properties file
            prop.load(input);
            host = prop.getProperty("dbhost");
            name = prop.getProperty("dbname");
            user = prop.getProperty("dbuser");
            pw = prop.getProperty("dbpassword");
            
            PostgresConnector pc = new PostgresConnector(host, name, user, pw);

            // estabelecer a ligacao à bd
            pc.connect();
            Statement stmt = pc.getStatement();
            stmt.executeUpdate("UPDATE veiculo SET estadoadm='aprovado' WHERE matricula='" + matricula + "';");
            
            input.close();
            pc.disconnect();
            stmt.close();
        }
        catch(Exception e){
            return e.getMessage();
        }
        return resultados;
    }
    
    private void atualizarEstados(){
        String host = "", name = "", user = "", pw = "";
        String resultados = "";
        
        try{
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();

            // load a properties file
            prop.load(input);
            host = prop.getProperty("dbhost");
            name = prop.getProperty("dbname");
            user = prop.getProperty("dbuser");
            pw = prop.getProperty("dbpassword");
            
            PostgresConnector pc = new PostgresConnector(host, name, user, pw);

            // estabelecer a ligacao à bd
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res;
            
            // Verifica se existe algum veiculo com o estado 'alugado' depois de passar a data final do aluguer
            LocalDate currentDate = LocalDate.now(); // Cria uma LocalDate da data atual
            String currentDateString = "".concat(currentDate.getDayOfMonth() + "-" + 
                    currentDate.getMonthValue() + "-" + currentDate.getYear()); // Converte a LocalDate para String
            SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy"); // cria um forato de data 
            Date date = formatter.parse(currentDateString); // Converte a string da data atual para uma Date
            Date dataAtual = new Date(date.getTime());
            res = stmt.executeQuery("SELECT veiculo.matricula, estado, data_fim FROM veiculo, aluguer WHERE veiculo.matricula=aluguer.matricula;");
            java.sql.Date dataFimRes;
            String matriculasPorAlterar = "";
            while(res.next()){
                dataFimRes = res.getDate("data_fim");
                String matriculaRes = res.getString("matricula");
                System.out.println("dataAtual: "+ dataAtual + "  |  dataFimRes: " + dataFimRes);
                if(dataFimRes.before(dataAtual)){
                    matriculasPorAlterar = matriculasPorAlterar.concat(matriculaRes + " ");
                }
            }
            String[] ArrayDeMatriculas = matriculasPorAlterar.split("\s");
            for(String mat : ArrayDeMatriculas){
                stmt.executeUpdate("UPDATE veiculo SET estado='disponivel' WHERE estado='alugado' AND matricula='" + mat + "';" );
            }
            
            // Verifica se existe algum veiculo com o estado 'alugado' depois de passar a data final do aluguer
            
            res = stmt.executeQuery("SELECT veiculo.matricula, estado, data_fim, data_inicio FROM veiculo, aluguer WHERE veiculo.matricula=aluguer.matricula;");
            
            matriculasPorAlterar = "";
            while(res.next()){
                Date dataInicioRes = res.getDate("data_inicio");
                dataFimRes = res.getDate("data_fim");
                String matriculaRes = res.getString("matricula");
                System.out.println("dataAtual: "+ dataAtual + "  |  dataFimRes: " + dataFimRes);
                if(dataInicioRes.before(dataAtual) && dataFimRes.after(dataAtual)){
                    matriculasPorAlterar = matriculasPorAlterar.concat(matriculaRes + " ");
                }
            }
            ArrayDeMatriculas = matriculasPorAlterar.split("\s");
            for(String mat : ArrayDeMatriculas){
                stmt.executeUpdate("UPDATE veiculo SET estado='alugado' WHERE estado='disponivel' AND matricula='" + mat + "';" );
            }
            
            input.close();
            pc.disconnect();
            stmt.close();
        }
        catch(Exception e){
        }
    }
}
