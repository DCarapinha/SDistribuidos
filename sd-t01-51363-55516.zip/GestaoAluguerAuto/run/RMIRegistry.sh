#!/bin/bash
rmiregistry -J-classpath -Jbuild/classes 1098
