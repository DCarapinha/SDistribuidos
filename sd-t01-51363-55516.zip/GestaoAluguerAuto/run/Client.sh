#!/bin/bash
java -classpath  build/classes src/gestaoaluguerauto/Client.java
