#!/bin/bash
java -classpath  build/classes src/gestaoaluguerauto/Server.java
