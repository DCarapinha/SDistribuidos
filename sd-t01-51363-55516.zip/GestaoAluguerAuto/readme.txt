Após restaurar a base de dados e abrir um terminal dentro da pasta do trabalho,
poderá executar o programa com os seguintes comandos:

1. chmod +x run/RMIRegistry.sh
2. chmod +x run/Server.sh
3. chmod +x run/Client.sh
4. chmod +x run/ClientAdmin.sh
5. ./run/RMIRegistry.sh
6. ./run/Server.sh
7. ./run/Client.sh
8. ./run/ClientAdmin.sh
