#!/bin/bash
mvn compile && cls && mvn exec:java -Dexec.mainClass=Hospital.Client
