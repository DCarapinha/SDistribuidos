#!/bin/bash
./apache-activemq-6.1.4/bin/activemq console
