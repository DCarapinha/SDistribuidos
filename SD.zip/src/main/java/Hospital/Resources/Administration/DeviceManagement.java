package Hospital.Resources.Administration;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import java.io.FileInputStream;
import java.io.InputStream;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

import Hospital.PostgresConnector;
import java.io.IOException;
import java.sql.SQLException;

/**
 * Root resource (exposed at "device" path)
 */
@Path("device")
public class DeviceManagement {
    /**
     * Method handling the creation of a new IOT device. 
     * 
     * @param room      - Room where the device is installed
     * @param floor     - Floor where the device is installed
     * @param building  - Building where the device is installed
     * @param service   - Service where the device is installed
     * @return String that will be returned as a text/plain response.
     */
    @GET @Path("/create")
    @Produces(MediaType.TEXT_PLAIN)
    public String CreateDevice(@QueryParam("room") String room,
            @QueryParam("floor") String floor,
            @QueryParam("building") String building,
            @QueryParam("service") String service) {
        try {
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();
            prop.load(input);
            String host = prop.getProperty("dbhost");
            String port = prop.getProperty("dbport");
            String name = prop.getProperty("dbname");
            String user = prop.getProperty("dbuser");
            String pw = prop.getProperty("dbpassword");
            PostgresConnector pc = new PostgresConnector(host, port, name, user, pw);
            pc.connect();
            Statement stmt = pc.getStatement();
            /**
             * Create a new entry that associates a new device with its location
             */
            stmt.executeUpdate("INSERT INTO devices (id, room, floor, building, service) VALUES(DEFAULT, '" +
                    room + "','" +
                    floor + "','" +
                    building + "','" +
                    service + "');");
            pc.disconnect();
        } catch (IOException | SQLException ex) {
            System.out.println("Exception: " + ex);
        }
        return "Device Created!";
    }

    
    /**
     * Method handling the listing of IOT devices.
     *
     * @return String that will be returned as a text/plain response.
     */
    @GET @Path("/list")
    @Produces(MediaType.TEXT_PLAIN)
    public String ListDevices() {
        String response = "";
        try {
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();
            prop.load(input);
            String host = prop.getProperty("dbhost");
            String port = prop.getProperty("dbport");
            String name = prop.getProperty("dbname");
            String user = prop.getProperty("dbuser");
            String pw = prop.getProperty("dbpassword");
            PostgresConnector pc = new PostgresConnector(host, port, name, user, pw);
            pc.connect();
            Statement stmt = pc.getStatement();
            /**
             * Get the last inserted id
             */
            ResultSet res = stmt.executeQuery("SELECT * FROM devices ORDER BY id");
            while(res.next()){
                response += String.format(
                          " ------------------------------ \n"
                        + "| id: %-24s |\n"
                        + "| sala: %-22s |\n"
                        + "| andar: %-21s |\n"
                        + "| edificio: %-18s |\n"
                        + "| servico: %-19s |\n",
                        res.getInt("id"), res.getInt("room"), 
                        res.getInt("floor"), res.getInt("building"),
                        res.getString("service"));
            }
            response += " ------------------------------ \n";
            pc.disconnect();
        } catch (IOException | SQLException ex) {
            System.out.println("Exception: " + ex);
        }
        return response;
    }

    
    /**
     * Method handling updates to IOT devices.
     * 
     * @param id - ID of the device to be updated
     * @param room - number of the new room
     * @param floor - number of the new floor
     * @param service - name of the new service
     * @param building - number of the new building
     * @return String that will be returned as a text/plain response.
     */
    @GET @Path("/update")
    @Produces(MediaType.TEXT_PLAIN)
    public String Update(@QueryParam("id") int id, 
            @QueryParam("room") String room,
            @QueryParam("floor") String floor,
            @QueryParam("service") String service,
            @QueryParam("building") String building) {
        try {
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();
            prop.load(input);
            String host = prop.getProperty("dbhost");
            String port = prop.getProperty("dbport");
            String name = prop.getProperty("dbname");
            String user = prop.getProperty("dbuser");
            String pw = prop.getProperty("dbpassword");
            PostgresConnector pc = new PostgresConnector(host, port, name, user, pw);
            pc.connect();
            Statement updateStmt = pc.getStatement();
            Statement queryStmt = pc.getStatement();
            ResultSet res = queryStmt.executeQuery("SELECT * FROM devices WHERE id="+id+";");
            /**
             * Validate the values that are being updated
             */
            room = room.equals("") ? res.getString("room") : room;
            floor = floor.equals("") ? res.getString("floor") : floor;
            building = building.equals("") ? res.getString("building") : building;
            service = service.equals("") ? res.getString("service") : service;
            /**
             * Updates a device with the given parameters
             */
            updateStmt.executeUpdate("UPDATE devices SET" +
                    " room=" + room +
                    ", floor=" + floor +
                    ", service='" + service +
                    "', building=" + building +
                    " WHERE id=" + id + ";");
                pc.disconnect();
           } catch (SQLException | IOException ex) {
               System.err.println("Excception: " + ex);
        }
        return "Updated!";
    }
    
    
    /**
     * Method handling the deletion of IOT devices.
     *
     * @param id - ID of the device to be deleted
     * @return String that will be returned as a text/plain response.
     */
    @GET @Path("/delete")
    @Produces(MediaType.TEXT_PLAIN)
    public String DeleteDevice(@QueryParam("id") int id) {
        try {
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();
            prop.load(input);
            String host = prop.getProperty("dbhost");
            String port = prop.getProperty("dbport");
            String name = prop.getProperty("dbname");
            String user = prop.getProperty("dbuser");
            String pw = prop.getProperty("dbpassword");
            PostgresConnector pc = new PostgresConnector(host, port, name, user, pw);
            pc.connect();
            Statement deleteStmt = pc.getStatement();
            deleteStmt.executeUpdate("DELETE FROM devices WHERE id="+id+";");
        } catch(IOException | SQLException ex){
            System.err.println("Exception: " + ex);
        }
        return "Deleted!";
    }
}
