package Hospital.Resources.Administration;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

import Hospital.PostgresConnector;
import java.io.IOException;
import java.sql.SQLException;

/**
 * Root resource (exposed at "check" path)
 */
@Path("check")
public class CheckMetrics {
    
    @GET @Path("/room")
    @Produces(MediaType.TEXT_PLAIN)
    public String checkRoom(@QueryParam("room") String room,
            @QueryParam("floor") String floor,
            @QueryParam("building") String building,
            @QueryParam("service") String service,
            @QueryParam("startDate") String startDate, 
            @QueryParam("endDate") String endDate){
                
        if(room == null) {
            throw new WebApplicationException(
              Response.status(Response.Status.BAD_REQUEST)
                .entity("room parameter is mandatory")
                .build()
            );
        }
        else if(floor == null){
            throw new WebApplicationException(
              Response.status(Response.Status.BAD_REQUEST)
                .entity("floor parameter is mandatory")
                .build()
            );
        }
        else if(building == null){
            throw new WebApplicationException(
              Response.status(Response.Status.BAD_REQUEST)
                .entity("building parameter is mandatory")
                .build()
            );
        }
        
        /**
         * Query for temperature and humidity of a room
        */
        String query = "SELECT AVG(temperature)::NUMERIC(10,2) AS tempAVG, AVG(humidity)::NUMERIC(10,2) AS humiAVG " +
                       "FROM devices, metrics WHERE room=" + room + 
                       " AND floor=" + floor +
                       " AND building=" + building +
                       " AND devices.id=metrics.id AND ";
        
        /**
         * Get the correct interval of time for the metrics
         */
        query += checkInterval(startDate, endDate);
        String response = "";
        try {
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();
            prop.load(input);
            String host = prop.getProperty("dbhost");
            String port = prop.getProperty("dbport");
            String name = prop.getProperty("dbname");
            String user = prop.getProperty("dbuser");
            String pw = prop.getProperty("dbpassword");
            PostgresConnector pc = new PostgresConnector(host, port, name, user, pw);
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                String resTemp = res.getString("tempavg");
                String resHumi = res.getString("humiavg");
                response += String.format(
                          " ------------------------------ \n"
                        + "| Room: %-22s |\n"
                        + "| Floor: %-21s |\n"
                        + "| Building: %-18s |\n"
                        + "| Service: %-19s |\n"
                        + "| Temperature: %-15s |\n"
                        + "| Humidity: %-18s |\n"
                        + " ------------------------------ \n",
                        room, floor, building, service, resTemp, resHumi);
            }  
        } catch (IOException | SQLException ex) {
            System.out.println("Exception: " + ex);
        }
        return response;
    }
    
    @GET @Path("/floor")
    @Produces(MediaType.TEXT_PLAIN)
    public String checkFloor(@QueryParam("floor") String floor,
            @QueryParam("service") String service,
            @QueryParam("building") String building,
            @QueryParam("startDate") String startDate, 
            @QueryParam("endDate") String endDate){
        
        if(floor == null){
            throw new WebApplicationException(
              Response.status(Response.Status.BAD_REQUEST)
                .entity("floor parameter is mandatory")
                .build()
            );
        }
        else if(service == null){
            throw new WebApplicationException(
              Response.status(Response.Status.BAD_REQUEST)
                .entity("service parameter is mandatory")
                .build()
            );
        }
        else if(building == null){
            throw new WebApplicationException(
              Response.status(Response.Status.BAD_REQUEST)
                .entity("building parameter is mandatory")
                .build()
            );
        }
        
        /**
         * Query for temperature and humidity of a floor
        */
        String query = "SELECT AVG(temperature)::NUMERIC(10,2) AS tempAVG, AVG(humidity)::NUMERIC(10,2) AS humiAVG " +
                       "FROM devices, metrics WHERE" + 
                       " floor=" + floor +
                       " AND building=" + building +
                       " AND service='" + service +
                       "' AND devices.id=metrics.id AND ";
        
        /**
         * Get the correct interval of time for the metrics
         */
        query += checkInterval(startDate, endDate);
        String response = "";
        try {
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();
            prop.load(input);
            String host = prop.getProperty("dbhost");
            String port = prop.getProperty("dbport");
            String name = prop.getProperty("dbname");
            String user = prop.getProperty("dbuser");
            String pw = prop.getProperty("dbpassword");
            PostgresConnector pc = new PostgresConnector(host, port, name, user, pw);
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                String resTemp = res.getString("tempavg");
                String resHumi = res.getString("humiavg");
                response += String.format(
                          " ------------------------------ \n"
                        + "| Floor: %-21s |\n"
                        + "| Building: %-18s |\n"
                        + "| Service: %-19s |\n"
                        + "| Temperature: %-15s |\n"
                        + "| Humidity: %-18s |\n"
                        + " ------------------------------ \n",
                        floor, building, service, resTemp, resHumi);
            }  
        } catch (IOException | SQLException ex) {
            System.out.println("Exception: " + ex);
        }
        return response;
    }
    
    @GET @Path("/building")
    @Produces(MediaType.TEXT_PLAIN)
    public String checkBuilding(@QueryParam("building") String building,
            @QueryParam("service") String service,
            @QueryParam("startDate") String startDate, 
            @QueryParam("endDate") String endDate){
        
        if(service == null){
            throw new WebApplicationException(
              Response.status(Response.Status.BAD_REQUEST)
                .entity("service parameter is mandatory")
                .build()
            );
        }
        else if(building == null){
            throw new WebApplicationException(
              Response.status(Response.Status.BAD_REQUEST)
                .entity("building parameter is mandatory")
                .build()
            );
        }
        
        /**
         * Query for temperature and humidity of a building
        */
        String query = "SELECT AVG(temperature)::NUMERIC(10,2) AS tempavg, AVG(humidity)::NUMERIC(10,2) AS humiavg " +
                       "FROM devices, metrics WHERE" +
                       " building=" + building +
                       " AND service='" + service +
                       "' AND devices.id=metrics.id AND ";
        
        /**
         * Get the correct interval of time for the metrics
         */
        query += checkInterval(startDate, endDate);
        System.out.println("\n\n\n"+query+"\n\n");
        String response = "";
        try {
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();
            prop.load(input);
            String host = prop.getProperty("dbhost");
            String port = prop.getProperty("dbport");
            String name = prop.getProperty("dbname");
            String user = prop.getProperty("dbuser");
            String pw = prop.getProperty("dbpassword");
            PostgresConnector pc = new PostgresConnector(host, port, name, user, pw);
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                String resTemp = res.getString("tempavg");
                String resHumi = res.getString("humiavg");
                response += String.format(
                          " ------------------------------ \n"
                        + "| Building: %-18s |\n"
                        + "| Service: %-19s |\n"
                        + "| Temperature: %-15s |\n"
                        + "| Humidity: %-18s |\n"
                        + " ------------------------------ \n",
                        building, service, resTemp, resHumi);
            }  
        } catch (IOException | SQLException ex) {
            System.out.println("Exception: " + ex);
        }
        return response;
    }
    
    @GET @Path("/service")
    @Produces(MediaType.TEXT_PLAIN)
    public String checkService(@QueryParam("service") String service, 
            @QueryParam("startDate") String startDate, 
            @QueryParam("endDate") String endDate){
        
        if(service == null){
            throw new WebApplicationException(
              Response.status(Response.Status.BAD_REQUEST)
                .entity("service parameter is mandatory")
                .build()
            );
        }
        
        /**
         * Query for temperature and humidity of a building
        */
        String query = "SELECT AVG(temperature)::NUMERIC(10,2) AS tempAVG, AVG(humidity)::NUMERIC(10,2) AS humiAVG " +
                       "FROM devices, metrics WHERE" +
                       " service='" + service +
                       "' AND devices.id=metrics.id AND ";
        
        /**
         * Get the correct interval of time for the metrics
         */
        query += checkInterval(startDate, endDate);
        String response = "";
        try {
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();
            prop.load(input);
            String host = prop.getProperty("dbhost");
            String port = prop.getProperty("dbport");
            String name = prop.getProperty("dbname");
            String user = prop.getProperty("dbuser");
            String pw = prop.getProperty("dbpassword");
            PostgresConnector pc = new PostgresConnector(host, port, name, user, pw);
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                String resTemp = res.getString("tempavg");
                String resHumi = res.getString("humiavg");
                response += String.format(
                          " ------------------------------ \n"
                        + "| Service: %-19s |\n"
                        + "| Temperature: %-15s |\n"
                        + "| Humidity: %-18s |\n"
                        + " ------------------------------ \n",
                        service, resTemp, resHumi);
            }  
        } catch (IOException | SQLException ex) {
            System.out.println("Exception: " + ex);
        }
        return response;
    }
    
    private String checkInterval(String startDate, String endDate){
        String interval = "";
        if(startDate.equals("") && endDate.equals("")){
            interval += "timestamp > now() - INTERVAL '24 HOURS';";
        } 
        /**
         * Only date given is startDate
         * Query of the entries with timestamp greater than startDate
         */
        else if(!startDate.equals("") && endDate.equals("")){
            interval += "timestamp > '" + startDate + "';";
        } 
        /**
         * Only date given is endDate
         * Query of the entries with timestamp smaller than endDate
         */
        else if(startDate.equals("") && !endDate.equals("")){
            interval += "timestamp < '" + endDate + "';";
        } 
        /**
         * Given startDate and endDate
         * Query of the entries with timestamp between startDate and endDate
         */
        else{
            interval += "timestamp > '" + startDate + "' AND "
                   + "timestamp < '" + endDate + "';";
        }
        return interval;
    }
}