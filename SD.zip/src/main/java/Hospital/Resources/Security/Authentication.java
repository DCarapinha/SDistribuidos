package Hospital.Resources.Security;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Arrays;

import Hospital.PostgresConnector;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.Properties;

/**
 *
 * @author dc982
 */

/**
 * Root resource (exposed at "auth" path)
 */
@Path("auth")
public class Authentication {
    @GET @Path("/")
    @Produces(MediaType.TEXT_PLAIN)
    public boolean auth(@QueryParam("username") String username,
            @QueryParam("password") String password){
        
        byte[] passwordhash = hash(password);
        
        String passwordHashRes = "";
        
        try {
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();
            prop.load(input);
            String host = prop.getProperty("dbhost");
            String port = prop.getProperty("dbport");
            String name = prop.getProperty("dbname");
            String user = prop.getProperty("dbuser");
            String pw = prop.getProperty("dbpassword");
            PostgresConnector pc = new PostgresConnector(host, port, name, user, pw);
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res = stmt.executeQuery("SELECT password FROM users WHERE username='"+username+"';");
            while(res.next()){
                passwordHashRes = res.getString("password");
            }
        } catch (IOException | SQLException ex) {
            System.out.println("Exception: " + ex);
        }
        return passwordHashRes.equals(Arrays.toString(passwordhash));
    }
    
    private static byte[] hash(String passwordToHash){
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-512");
            byte[] hashedPassword = md.digest(passwordToHash.getBytes(StandardCharsets.UTF_8));
            return hashedPassword;
        } catch (NoSuchAlgorithmException ex) {
            System.out.println("Exception:" + ex);
            System.exit(1);
        }
        return new byte[] {0};
    }
}
