package Hospital;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.Properties;
import java.util.Random;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author dc982
 */

public class DeviceSimulator {
    public static void main(String args[]) throws MqttException, InterruptedException{
        String clientId     = "DeviceController";
        String broker       = "tcp://localhost:1883"; // URL de um Broker ativo
        String topic        = "Device Metrics"; // topico para onde enviar a mensagem
        int qos             = 2; // mensagem enviada uma unica vez
        /**
        * Updates devices with 2 seconds of interval
        */
        try {
            InputStream input = new FileInputStream("configs.properties");
            Properties prop = new Properties();
            prop.load(input);
            String host = prop.getProperty("dbhost");
            String port = prop.getProperty("dbport");
            String name = prop.getProperty("dbname");
            String user = prop.getProperty("dbuser");
            String pw = prop.getProperty("dbpassword");
            PostgresConnector pc = new PostgresConnector(host, port, name, user, pw);
            pc.connect();
            try (MqttClient sampleClient = new MqttClient(broker, clientId, new MemoryPersistence())) {
                MqttConnectOptions connOpts = new MqttConnectOptions();
                connOpts.setCleanSession(true);
                System.out.println("Connecting to broker: " + broker);
                sampleClient.connect(connOpts);
                System.out.println("Connected");
                while(true){ // loop forever
                    Statement stmt = pc.getStatement();
                    ResultSet activeDevices = stmt.executeQuery("SELECT id FROM devices ORDER BY id;");
                    while(activeDevices.next()){ // loop through all active devices
                        JSONObject content = new JSONObject();
                        content.put("id", activeDevices.getInt("id"));
                        content.put("temperature", new Random().nextDouble() * (31 - 20) + 20);
                        content.put("humidity", new Random().nextDouble() * (0.6 - 0.4) + 0.4);
                        content.put("timestamp", LocalDateTime.now());
                        
                        MqttMessage message = new MqttMessage(content.toString().getBytes("UTF-8"));
                        message.setQos(qos);
                        sampleClient.publish(topic, message);
                        System.out.println("Message published");
                        Thread.sleep(2000);
                    }
                    Thread.sleep(10000);
                }
            }
        } catch (IOException | InterruptedException | SQLException | MqttException | JSONException ex) {
            System.out.println("Exception: " + ex);
        }
    }
}