package Hospital;

import java.sql.*;

/**
 *
 * @author jsaias
 */
public class PostgresConnector {

    private final String PG_HOST;
    private final String PG_PORT;
    private final String PG_DB;
    private final String USER;
    private final String PWD;

    Connection con = null;
    Statement stmt = null;

    public PostgresConnector(String host, String port, String db, String user, String pw) {
        PG_HOST=host;
        PG_PORT=port;
        PG_DB=db;
        USER=user;
        PWD= pw;
    }

    public void connect() {
        try {
            Class.forName("org.postgresql.Driver");
            // url = "jdbc:postgresql://host:port/database",
            con = DriverManager.getConnection("jdbc:postgresql://" + PG_HOST + ":" + PG_PORT + "/" + PG_DB,
                    USER,
                    PWD);

            stmt = con.createStatement();

        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Problems setting the connection");
        }
    }

    public void disconnect() {    // importante: fechar a ligacao a BD
        try {
            stmt.close();
            con.close();
        } catch (SQLException e) {
            System.err.println("Problems disconnecting");
        }
    }

    public Statement getStatement() {
        return stmt;
    }

}
