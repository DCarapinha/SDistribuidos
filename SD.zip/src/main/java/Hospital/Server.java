package Hospital;

import java.io.FileInputStream;
import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Server extends Thread{
    // Base URI the Grizzly HTTP server will listen on
    public static final String BASE_URI = "http://localhost:8080/";
    /**
     * Starts Grizzly HTTP server exposing JAX-RS resources defined in this
     * application.
     * 
     * @return Grizzly HTTP server.
     */
    public static HttpServer startServer() {
        // create a resource config that scans for JAX-RS resources and providers
        // in Hosital package
        final ResourceConfig rc = new ResourceConfig().packages("Hosital");

        // create and start a new instance of grizzly http server
        // exposing the Jersey application at BASE_URI
        return GrizzlyHttpServerFactory.createHttpServer(URI.create(BASE_URI), rc);
    }

    /**
     * Main method.
     * 
     * @param args
     * @throws IOException
     * @throws java.lang.InterruptedException
     */
    public static void main(String[] args) throws IOException, InterruptedException {
        try {
            final HttpServer server = startServer();
            Server thread = new Server();
            thread.start();
            System.out.println(String.format("Jersey app started with endpoints available at "
                    + "%s%nHit Ctrl-C to stop it...", BASE_URI));
            System.in.read();
            server.stop();
        } catch (IOException ex) {
            System.err.println("IOException: " + ex);
        }
    }
    
    @Override
    public void run(){
        String clientId     = "Server";
        String topic        = "Device Metrics"; // confirme que é o tópico certo
        String broker= "tcp://localhost:1883"; // verifique se é o mesmo endereço
        try (MqttClient sampleClient = new MqttClient(broker, clientId, new MemoryPersistence())) {
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);
            
            sampleClient.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) { 
                    System.out.println("Connection With Broker Lost");
                }
                public void connectComplete(boolean reconnect, java.lang.String serverURI) {
                    System.out.println("Connection With Broker Established At " + serverURI);
                }
                @Override
                public void messageArrived(String topic, MqttMessage message){
                    try {
                        JSONParser parser = new JSONParser();
                        JSONObject json = (JSONObject) parser.parse(message.toString());
                        
                        InputStream input = new FileInputStream("configs.properties");
                        Properties prop = new Properties();
                        prop.load(input);
                        String host = prop.getProperty("dbhost");
                        String port = prop.getProperty("dbport");
                        String name = prop.getProperty("dbname");
                        String user = prop.getProperty("dbuser");
                        String pw = prop.getProperty("dbpassword");
                        PostgresConnector pc = new PostgresConnector(host, port, name, user, pw);
                        pc.connect();
                        Statement stmt = pc.getStatement();
                        stmt.executeUpdate("INSERT INTO metrics (temperature, humidity, timestamp, id) " +
                            "VALUES("+ (double) json.get("temperature") +
                            ", "+ (double) json.get("humidity") + 
                            ", '"+ (String) json.get("timestamp") +
                            "', "+ (String) json.get("id").toString() + ");"
                        );
                    } catch (IOException | SQLException | ParseException ex) {
                        System.err.println("Exception: " + ex);
                    }
                }
                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                }
            });
            
            System.out.println("Connecting to broker: "+broker);
            sampleClient.connect(connOpts);
            System.out.println("Connected");
            sampleClient.subscribe(topic);
            while(true) { // loop forever getting updates
            }
        } catch (Exception ex) {
            System.err.println("Exception: " + ex);
        }
    }
}
