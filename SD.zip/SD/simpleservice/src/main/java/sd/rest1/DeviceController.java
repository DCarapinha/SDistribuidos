/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sd.rest1;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import java.util.ArrayList;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author dc982
 */
public class DeviceController {
    private ArrayList<Device> devices = new ArrayList<Device>();
    private int id = 0;
    public DeviceController(){
    }
    public int getNextID(){
        return id++;
    }
    public int getID(int DeviceID){
        return devices.indexOf(DeviceID);
    }
    public ArrayList getDevices(){
        return devices;
    }
    public int getLenght(){
        return devices.size();
    }
}
