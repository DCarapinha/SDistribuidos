package sd.rest1.resources.Administration;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import sd.rest1.Device;
import sd.rest1.DeviceController;
import sd.rest1.PostgresConnector;

/**
 * @author dc982
 */

 /**
 * Root resource (exposed at "/create/device" path)
 */
@Path("/create/device")
public class CreateDevice {
    
    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @return String that will be returned as a text/plain response.
     */
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String CreateDevice() {
        PostgresConnector pc = new PostgresConnector("localhost", "8081", "user1", "umaPass");
        try {
            // estabelecer a ligacao ao SGBD
            pc.connect();
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        Statement stmt = pc.getStatement();
        
        
        
        
        /*DeviceController DC = new DeviceController();
        Device newDevice = new Device(DC.getNextID());
        DC.getDevices().add(newDevice);
        
        System.out.println("SIZE:"+DC.getDevices().size());
        for(int n = 0; n < DC.getLenght(); n++){
            System.out.println("DEVICEID:"+DC.getID(n));
        }*/
        
        pc.disconnect();
        return "Device Created!";
    }   
}
