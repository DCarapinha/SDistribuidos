package sd.rest1.resources.Security;

import com.sun.org.slf4j.internal.LoggerFactory;
import com.sun.org.slf4j.internal.Logger;

import java.util.function.Function;
import org.mindrot.jbcrypt.BCrypt;

public class UpdatableBCrypt {

    private final int logRounds;

    public UpdatableBCrypt(int logRounds) {
        this.logRounds = logRounds;
    }

    public String hash(String password) {
        return BCrypt.hashpw(password, BCrypt.gensalt(logRounds));
    }

    public boolean verifyHash(String password, String hash) {
        return BCrypt.checkpw(password, hash);
    }

    public boolean verifyAndUpdateHash(String password, String hash, Function<String, Boolean> updateFunc) {
        if (BCrypt.checkpw(password, hash)) {
            int rounds = getRounds(hash);
            // It might be smart to only allow increasing the rounds.
            // If someone makes a mistake the ability to undo it would be nice though.
            if (rounds != logRounds) {
                System.out.println("Updating password from" + rounds + "rounds to "+ logRounds);
                String newHash = hash(password);
                return updateFunc.apply(newHash);
            }
            return true;
        }
        return false;
    }

    /*
     * Copy pasted from BCrypt internals :(. Ideally a method
     * to exports parts would be public. We only care about rounds
     * currently.
     */
    private int getRounds(String salt) {
        char minor = (char)0;
        int off = 0;

        if (salt.charAt(0) != '$' || salt.charAt(1) != '2')
            throw new IllegalArgumentException ("Invalid salt version");
        if (salt.charAt(2) == '$')
            off = 3;
        else {
            minor = salt.charAt(2);
            if (minor != 'a' || salt.charAt(3) != '$')
                throw new IllegalArgumentException ("Invalid salt revision");
            off = 4;
        }

        // Extract number of rounds
        if (salt.charAt(off + 2) > '$')
            throw new IllegalArgumentException ("Missing salt rounds");
        return Integer.parseInt(salt.substring(off, off + 2));
    }
    
    public static void main(String args[]){
        // Mini function to test updates.
        
        String[] mutableHash = new String[1];
        Function<String, Boolean> update = hash -> { mutableHash[0] = hash; return true; };

        String hashPw1 = Hashing.hash("admin");
        System.out.println("hash of pw1: "+ hashPw1);
        System.out.println("verifying pw1: " + Hashing.verifyAndUpdateHash("password", hashPw1, update));
        System.out.println("verifying pw1 fails: "+ Hashing.verifyAndUpdateHash("password1", hashPw1, update));
        
        String hashPw2 = Hashing.hash("password");
        System.out.println("hash of pw2: " + hashPw2);
        System.out.println("verifying pw2: " + Hashing.verifyAndUpdateHash("password", hashPw2, update));
        System.out.println("verifying pw2 fails: " + Hashing.verifyAndUpdateHash("password2", hashPw2, update));

        UpdatableBCrypt oldHasher = new UpdatableBCrypt(7);
        String oldHash = oldHasher.hash("password");
        System.out.println("hash of oldHash: "+ oldHash);
        System.out.println("verifying oldHash: " + 
                    Hashing.verifyAndUpdateHash("password", oldHash, update) +
                    ", hash upgraded to: " +
                    mutableHash[0]);
    }
}