package sd.rest1.resources.Administration;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import sd.rest1.PostgresConnector;

/**
 * Root resource (exposed at "check" path)
 */
@Path("check")
public class Check {
    
    /**
     * @param room - The number of the rooms
     * @param startDate - Start Date with the format (yyyy-mm-dd)
     * @param endDate - End Date with the format (yyyy-mm-dd)
     * @return 
     */
    
    @GET @Path("/room")
    @Produces(MediaType.TEXT_PLAIN)
    public String checkRoom(@QueryParam("room") String room, 
            @QueryParam("startDate") String startDate, 
            @QueryParam("endDate") String endDate){
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */
        
        PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        room = room == null ? "" : "room=" + room;
        /**
         * Query for temperature and humidity of rooms
        */
        String query = "";
        /**
         * No dates where given
         * Query of the last 24 Hours
         */
        if(startDate == null && endDate == null){
            query = "SELECT AVG(temperatura)::NUMERIC(10,2) AS tempAVG, AVG(humidade)::NUMERIC(10,2) AS humiAVG FROM device, location WHERE " + 
                    room + " AND device.id=location.id AND timestamp > now() - INTERVAL '24 HOURS';";
        } 
        /**
         * Only date given is startDate
         * Query of the entries with timestamp greater than startDate
         */
        else if(startDate != null && endDate == null){
            query = "SELECT AVG(temperatura)::NUMERIC(10,2) AS tempAVG, AVG(humidade)::NUMERIC(10,2) AS humiAVG FROM device, location WHERE " + 
                    room + " AND device.id=location.id AND timestamp > '" + startDate + "';";
        } 
        /**
         * Only date given is endDate
         * Query of the entries with timestamp smaller than endDate
         */
        else if(startDate == null && endDate != null){
            query = "SELECT AVG(temperatura)::NUMERIC(10,2) AS tempAVG, AVG(humidade)::NUMERIC(10,2) AS humiAVG FROM device, location WHERE " + 
                    room + " AND device.id=location.id AND timestamp < '" + endDate + "';";
        } 
        /**
         * Given startDate and endDate
         * Query of the entries with timestamp between startDate and endDate
         */
        else{
            query = "SELECT AVG(temperatura)::NUMERIC(10,2) AS tempAVG, AVG(humidade)::NUMERIC(10,2) AS humiAVG FROM device, location WHERE " + 
                    room + " AND device.id=location.id AND timestamp > '" + startDate + "' AND"
                    + "timestamp < '" + endDate + "';";
        }
        try {
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res = stmt.executeQuery(query);
            
            while(res.next()){
                String resTemp = res.getString("tempavg");
                String resHumi = res.getString("humiavg");
                
                System.out.println("------------------------\n Room: " + room.substring(5, 6));
                System.out.println(" Temperature: " + resTemp);
                System.out.println(" Humidity: " + resHumi);
            }
            
            
            
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }

        
        
        return "Checked room!";
    }
    
    @GET @Path("/floor")
    @Produces(MediaType.TEXT_PLAIN)
    public String checkFloor(@QueryParam("floor") String floor, 
            @QueryParam("startDate") String startDate, 
            @QueryParam("endDate") String endDate){
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */
        
        PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        floor = floor == null ? "" : "floor=" + floor;
        /**
         * Query for temperature and humidity of floors
        */
        String query = "";
        /**
         * No dates where given
         * Query of the last 24 Hours
         */
        if(startDate == null && endDate == null){
            query = "SELECT AVG(temperatura)::NUMERIC(10,2) AS tempAVG, AVG(humidade)::NUMERIC(10,2) AS humiAVG FROM device, location WHERE " + 
                    floor + " AND device.id=location.id AND timestamp > now() - INTERVAL '24 HOURS';";
        } 
        /**
         * Only date given is startDate
         * Query of the entries with timestamp greater than startDate
         */
        else if(startDate != null && endDate == null){
            query = "SELECT AVG(temperatura)::NUMERIC(10,2) AS tempAVG, AVG(humidade)::NUMERIC(10,2) AS humiAVG FROM device, location WHERE " + 
                    floor + " AND device.id=location.id AND timestamp > '" + startDate + "';";
        } 
        /**
         * Only date given is endDate
         * Query of the entries with timestamp smaller than endDate
         */
        else if(startDate == null && endDate != null){
            query = "SELECT AVG(temperatura)::NUMERIC(10,2) AS tempAVG, AVG(humidade)::NUMERIC(10,2) AS humiAVG FROM device, location WHERE " + 
                    floor + " AND device.id=location.id AND timestamp < '" + endDate + "';";
        } 
        /**
         * Given startDate and endDate
         * Query of the entries with timestamp between startDate and endDate
         */
        else{
            query = "SELECT AVG(temperatura)::NUMERIC(10,2) AS tempAVG, AVG(humidade)::NUMERIC(10,2) AS humiAVG FROM device, location WHERE " + 
                    floor + " AND device.id=location.id AND timestamp > '" + startDate + "' AND"
                    + "timestamp < '" + endDate + "';";
        }
        try {
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res = stmt.executeQuery(query);
            
            while(res.next()){
                String resTemp = res.getString("tempavg");
                String resHumi = res.getString("humiavg");
                
                System.out.println("------------------------\n Room: " + floor.substring(6, 7));
                System.out.println(" Temperature: " + resTemp);
                System.out.println(" Humidity: " + resHumi);
            }
            
            
            
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        
        return "Checked floor!";
    }
    
    @GET @Path("/building")
    @Produces(MediaType.TEXT_PLAIN)
    public String checkBuilding(@QueryParam("building") String building, 
            @QueryParam("startDate") String startDate, 
            @QueryParam("endDate") String endDate){
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */
        
        PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        building = building == null ? "" : "building=" + building;
        try {
            pc.connect();
            
        } catch(Exception e){
            System.out.println("Exception: " + e);
        }
        
        return "Checked building!";
    }
    
    @GET @Path("/service")
    @Produces(MediaType.TEXT_PLAIN)
    public String checkService(@QueryParam("service") String service, 
            @QueryParam("startDate") String startDate, 
            @QueryParam("endDate") String endDate){
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */
        
        PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        service = service == null ? "" : "service=" + service;
        try {
            pc.connect();
            
        } catch(Exception e){
            System.out.println("Exception: " + e);
        }
        return "Checked service!";
    }
    
    
    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @param room
     * @param service
     * @param floor
     * @param building
     * @return String that will be returned as a text/plain response.
     */
    @GET @Path("/")
    @Produces(MediaType.TEXT_PLAIN)
    public String consulta(@QueryParam("room") String room, 
            @QueryParam("floor") String floor, 
            @QueryParam("building") String building,
            @QueryParam("service") String service) {
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */
        
    PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        try {
            pc.connect();
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        try {
            
            /**
             * Validate the values that are being updated
             * If the parameter is 'null' (no value is being parsed)
             * there won't be a filter for it
             */
            
            room = room == null ? "" : "room=" + room + " AND ";
            floor = floor == null ? "" : "floor=" + floor + " AND ";
            building = building == null ? "" : "building=" + building + " AND ";
            service = service == null ? "" : "service='" + service + "' AND ";
            
            String query = "SELECT * FROM location WHERE " + room + floor + building + service;
            query = query.substring(0, query.length() - 5) + " ORDER BY id;";
            System.out.println(query);
            /**
             * Query for 
             */
           
            Statement stmt = pc.getStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                String resRoom = res.getString("room");
                String resFloor = res.getString("floor");
                String resBuilding = res.getString("building");
                String resService = res.getString("service");
                
                System.out.println("------------------------\n Room: " + resRoom);
                System.out.println(" Floor: " + resFloor);
                System.out.println(" Building: " + resBuilding);
                System.out.println(" Service: " + resService);
            }
            try {
                Thread.sleep(2000);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return "Checked!";
    }
}