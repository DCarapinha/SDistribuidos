package sd.rest1.resources.Administration;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import sd.rest1.PostgresConnector;

/**
 * Root resource (exposed at "check" path)
 */
@Path("check")
public class Check {
    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @param room
     * @param service
     * @param floor
     * @param building
     * @return String that will be returned as a text/plain response.
     */
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String consulta(@QueryParam("room") String room, 
            @QueryParam("floor") String floor, 
            @QueryParam("building") String building,
            @QueryParam("service") String service) {
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - db name
         * @param 3 - user
         * @param 4 - password
         */
        PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        try {
            pc.connect();
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        try {
            
            /**
             * Validate the values that are being updated
             * If the parameter is 'null' (no value is being parsed)
             * there won't be a filter for it
             */
            
            room = room == null ? "" : "room=" + room + " AND ";
            floor = floor == null ? "" : "floor=" + floor + " AND";
            building = building == null ? "" : "building=" + building + "AND";
            service = service == null ? "" : "service=" + service + "AND";
            String query = room + floor + building + service;
            
            // TODO: remove last 'AND'
            
            /**
             * Updates a device with the given parameters
             */
            Statement stmt = pc.getStatement();
            ResultSet res = stmt.executeQuery("SELECT * FROM location WHERE ");
            
            try {
                Thread.sleep(2000);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return "Checked!";
    }
}