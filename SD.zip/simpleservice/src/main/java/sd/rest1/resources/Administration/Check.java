package sd.rest1.resources.Administration;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import sd.rest1.PostgresConnector;

/**
 * Root resource (exposed at "check" path)
 */
@Path("check")
public class Check {
    
    @GET @Path("/room")
    @Produces(MediaType.TEXT_PLAIN)
    public String checkRoom(@QueryParam("room") String room){
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */
        
    PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        try {
            pc.connect();
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        try {
        } catch(Exception e){
        }
            
        
        room = room == null ? "" : "room=" + room + ";";

        
        
        return "Checked room!";
    }
    
    @GET @Path("/floor")
    @Produces(MediaType.TEXT_PLAIN)
    public String checkFloor(@QueryParam("floor") String floor){
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */
        
        PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        try {
            pc.connect();
            
        } catch(Exception e){
            System.out.println("Exception: " + e);
        }
        
        floor = floor == null ? "" : "floor=" + floor + ";";
        return "Checked floor!";
    }
    
    @GET @Path("/building")
    @Produces(MediaType.TEXT_PLAIN)
    public String checkBuilding(@QueryParam("building") String building){
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */
        
        PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        try {
            pc.connect();
            
        } catch(Exception e){
            System.out.println("Exception: " + e);
        }
        
        building = building == null ? "" : "building=" + building + ";";
        return "Checked building!";
    }
    
    @GET @Path("/service")
    @Produces(MediaType.TEXT_PLAIN)
    public String checkService(@QueryParam("service") String service){
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */
        
        PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        try {
            pc.connect();
            
        } catch(Exception e){
            System.out.println("Exception: " + e);
        }
        service = service == null ? "" : "service=" + service + ";";
        return "Checked service!";
    }
    
    
    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @param room
     * @param service
     * @param floor
     * @param building
     * @return String that will be returned as a text/plain response.
     */
    @GET @Path("/")
    @Produces(MediaType.TEXT_PLAIN)
    public String consulta(@QueryParam("room") String room, 
            @QueryParam("floor") String floor, 
            @QueryParam("building") String building,
            @QueryParam("service") String service) {
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */
        
    PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        try {
            pc.connect();
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        try {
            
            /**
             * Validate the values that are being updated
             * If the parameter is 'null' (no value is being parsed)
             * there won't be a filter for it
             */
            String query = "SELECT * FROM location WHERE " + room + floor + building + service;
            query = query.substring(0, query.length() - 4);
            
            /**
             * Query for 
             */
           
            Statement stmt = pc.getStatement();
            ResultSet res = stmt.executeQuery("SELECT * FROM location WHERE ");
            
            try {
                Thread.sleep(2000);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return "Checked!";
    }
}