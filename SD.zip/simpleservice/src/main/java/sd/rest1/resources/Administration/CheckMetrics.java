package sd.rest1.resources.Administration;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.sql.ResultSet;
import java.sql.Statement;

import sd.rest1.PostgresConnector;

/**
 * Root resource (exposed at "check" path)
 */
@Path("check")
public class CheckMetrics {
    
    /**
     * @param room - The number of the room
     * @param floor - The floor the room is located on
     * @param building - The building the room is located on
     * @param startDate - Start Date with the format (yyyy-mm-dd)
     * @param endDate - End Date with the format (yyyy-mm-dd)
     * @return 
     */
    
    @GET @Path("/room")
    @Produces(MediaType.TEXT_PLAIN)
    public String checkRoom(@QueryParam("room") String room,
            @QueryParam("floor") String floor,
            @QueryParam("building") String building,
            @QueryParam("startDate") String startDate, 
            @QueryParam("endDate") String endDate){
                
        if(room == null) {
            throw new WebApplicationException(
              Response.status(Response.Status.BAD_REQUEST)
                .entity("room parameter is mandatory")
                .build()
            );
        }
        else if(floor == null){
            throw new WebApplicationException(
              Response.status(Response.Status.BAD_REQUEST)
                .entity("floor parameter is mandatory")
                .build()
            );
        }
        else if(building == null){
            throw new WebApplicationException(
              Response.status(Response.Status.BAD_REQUEST)
                .entity("building parameter is mandatory")
                .build()
            );
        }
        
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */       
        PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        /**
         * Query for temperature and humidity of a room
        */
        String query = "SELECT AVG(temperature)::NUMERIC(10,2) AS tempAVG, AVG(humidity)::NUMERIC(10,2) AS humiAVG " +
                       "FROM device, location WHERE room=" + room + 
                       " AND floor=" + floor +
                       " AND building=" + building +
                       " AND device.id=location.id AND ";
        
        /**
         * No dates were given
         * Query of the last 24 Hours
         */
        if(startDate.equals("null") && endDate.equals("null")){
            query += "timestamp > now() - INTERVAL '24 HOURS';";
        } 
        /**
         * Only date given is startDate
         * Query of the entries with timestamp greater than startDate
         */
        else if(!startDate.equals("null") && endDate.equals("null")){
            query += "timestamp > '" + startDate + "';";
        } 
        /**
         * Only date given is endDate
         * Query of the entries with timestamp smaller than endDate
         */
        else if(startDate.equals("null") && !endDate.equals("null")){
            query += "timestamp < '" + endDate + "';";
        } 
        /**
         * Given startDate and endDate
         * Query of the entries with timestamp between startDate and endDate
         */
        else{
            query += "timestamp > '" + startDate + "' AND "
                   + "timestamp < '" + endDate + "';";
        }
        String response = "";
        try {
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                String resTemp = res.getString("tempavg");
                String resHumi = res.getString("humiavg");
                response += "\n Room: " + room +
                            "\n Temperature: " + resTemp +
                            "\n Humidity: " + resHumi;
            }  
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        return response;
    }
    
    @GET @Path("/floor")
    @Produces(MediaType.TEXT_PLAIN)
    public String checkFloor(@QueryParam("floor") String floor, 
            @QueryParam("service") String service,
            @QueryParam("building") String building,
            @QueryParam("startDate") String startDate, 
            @QueryParam("endDate") String endDate){
        
        if(floor == null){
            throw new WebApplicationException(
              Response.status(Response.Status.BAD_REQUEST)
                .entity("floor parameter is mandatory")
                .build()
            );
        }
        else if(service == null){
            throw new WebApplicationException(
              Response.status(Response.Status.BAD_REQUEST)
                .entity("service parameter is mandatory")
                .build()
            );
        }
        else if(building == null){
            throw new WebApplicationException(
              Response.status(Response.Status.BAD_REQUEST)
                .entity("building parameter is mandatory")
                .build()
            );
        }
        
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */        
        PostgresConnector pc = new PostgresConnector("localhost", "hospitalevora", "postgres", "admin");
        /**
         * Query for temperature and humidity of a floor
        */
        String query = "SELECT AVG(temperature)::NUMERIC(10,2) AS tempAVG, AVG(humidity)::NUMERIC(10,2) AS humiAVG " +
                       "FROM device, location WHERE" + 
                       " floor=" + floor +
                       " AND building=" + building +
                       " AND service='" + service +
                       "' AND device.id=location.id AND ";
        /**
         * No dates were given
         * Query of the last 24 Hours
         */
        if(startDate.equals("null") && endDate.equals("null")){
            query += "timestamp > now() - INTERVAL '24 HOURS';";
        } 
        /**
         * Only date given is startDate
         * Query of the entries with timestamp greater than startDate
         */
        else if(!startDate.equals("null") && endDate.equals("null")){
            query += "timestamp > '" + startDate + "';";
        } 
        /**
         * Only date given is endDate
         * Query of the entries with timestamp smaller than endDate
         */
        else if(startDate.equals("null") && !endDate.equals("null")){
            query += "timestamp < '" + endDate + "';";
        } 
        /**
         * Given startDate and endDate
         * Query of the entries with timestamp between startDate and endDate
         */
        else{
            query += "timestamp > '" + startDate + "' AND "
                   + "timestamp < '" + endDate + "';";
        }
        String response = "";
        try {
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                String resTemp = res.getString("tempavg");
                String resHumi = res.getString("humiavg");
                
                response += "------------------------\n Floor: " + floor +
                            "\n Temperature: " + resTemp +
                            "\n Humidity: " + resHumi;
            }  
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        return response;
    }
    
    @GET @Path("/building")
    @Produces(MediaType.TEXT_PLAIN)
    public String checkBuilding(@QueryParam("building") String building,
            @QueryParam("service") String service,
            @QueryParam("startDate") String startDate, 
            @QueryParam("endDate") String endDate){
        
        if(service == null){
            throw new WebApplicationException(
              Response.status(Response.Status.BAD_REQUEST)
                .entity("service parameter is mandatory")
                .build()
            );
        }
        else if(building == null){
            throw new WebApplicationException(
              Response.status(Response.Status.BAD_REQUEST)
                .entity("building parameter is mandatory")
                .build()
            );
        }
        
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */
        
        PostgresConnector pc = new PostgresConnector("localhost", "hospitalevora", "postgres", "admin");
        /**
         * Query for temperature and humidity of a building
        */
        String query = "SELECT AVG(temperature)::NUMERIC(10,2) AS tempAVG, AVG(humidity)::NUMERIC(10,2) AS humiAVG " +
                       "FROM device, location WHERE" +
                       " building=" + building +
                       " AND service='" + service +
                       "' AND device.id=location.id AND ";
        /**
         * No dates were given
         * Query of the last 24 Hours
         */
        if(startDate.equals("null") && endDate.equals("null")){
            query += "timestamp > now() - INTERVAL '24 HOURS';";
        } 
        /**
         * Only date given is startDate
         * Query of the entries with timestamp greater than startDate
         */
        else if(!startDate.equals("null") && endDate.equals("null")){
            query += "timestamp > '" + startDate + "';";
        } 
        /**
         * Only date given is endDate
         * Query of the entries with timestamp smaller than endDate
         */
        else if(startDate.equals("null") && !endDate.equals("null")){
            query += "timestamp < '" + endDate + "';";
        } 
        /**
         * Given startDate and endDate
         * Query of the entries with timestamp between startDate and endDate
         */
        else{
            query += "timestamp > '" + startDate + "' AND "
                   + "timestamp < '" + endDate + "';";
        }
        String response = "";
        try {
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                String resTemp = res.getString("tempavg");
                String resHumi = res.getString("humiavg");
                
                response += "------------------------\n Building: " + building +
                            "\n Temperature: " + resTemp +
                            "\n Humidity: " + resHumi;
            }  
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        return response;
    }
    
    @GET @Path("/service")
    @Produces(MediaType.TEXT_PLAIN)
    public String checkService(@QueryParam("service") String service, 
            @QueryParam("startDate") String startDate, 
            @QueryParam("endDate") String endDate){
        
        if(service == null){
            throw new WebApplicationException(
              Response.status(Response.Status.BAD_REQUEST)
                .entity("service parameter is mandatory")
                .build()
            );
        }
        
        
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */
        
        PostgresConnector pc = new PostgresConnector("localhost", "hospitalevora", "postgres", "admin");
        /**
         * Query for temperature and humidity of a building
        */
        String query = "SELECT AVG(temperature)::NUMERIC(10,2) AS tempAVG, AVG(humidity)::NUMERIC(10,2) AS humiAVG " +
                       "FROM device, location WHERE" +
                       " service='" + service +
                       "' AND device.id=location.id AND ";
        /**
         * No dates were given
         * Query of the last 24 Hours
         */
        if(startDate.equals("null") && endDate.equals("null")){
            query += "timestamp > now() - INTERVAL '24 HOURS';";
        } 
        /**
         * Only date given is startDate
         * Query of the entries with timestamp greater than startDate
         */
        else if(!startDate.equals("null") && endDate.equals("null")){
            query += "timestamp > '" + startDate + "';";
        } 
        /**
         * Only date given is endDate
         * Query of the entries with timestamp smaller than endDate
         */
        else if(startDate.equals("null") && !endDate.equals("null")){
            query += "timestamp < '" + endDate + "';";
        } 
        /**
         * Given startDate and endDate
         * Query of the entries with timestamp between startDate and endDate
         */
        else{
            query += "timestamp > '" + startDate + "' AND "
                   + "timestamp < '" + endDate + "';";
        }
        String response = "";
        try {
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res = stmt.executeQuery(query);
            while(res.next()){
                String resTemp = res.getString("tempavg");
                String resHumi = res.getString("humiavg");
                
                response += "------------------------\n Service: " + service +
                            "\n Temperature: " + resTemp +
                            "\n Humidity: " + resHumi;
            }  
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        return response;
    }
    
}