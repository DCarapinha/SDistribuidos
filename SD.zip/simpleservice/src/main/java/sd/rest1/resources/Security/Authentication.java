/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sd.rest1.resources.Security;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

import java.sql.ResultSet;
import java.sql.Statement;
import sd.rest1.PostgresConnector;

/**
 *
 * @author dc982
 */

/**
 * Root resource (exposed at "auth" path)
 */
@Path("auth")
public class Authentication {
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public boolean auth(@QueryParam("username") String username,
            @QueryParam("password") String passwordHash){
        
        // TODO: HASH IS ALWAYS DIFFERENT
        
        
        System.out.println("username: " + username);
        System.out.println("passwordHash: " + passwordHash);


        
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */       
        PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        int validUser = 0;
        try {
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res = stmt.executeQuery("SELECT count(id) as count FROM users WHERE username='"+username+"' AND " + 
                                              "password='" + passwordHash + "';");
            while(res.next()){
                validUser = res.getInt("count");
            }
            System.out.println("validUser: " + validUser);
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        return validUser == 1;
    }
}
