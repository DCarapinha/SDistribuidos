/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sd.rest1.resources.Security;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Arrays;

import sd.rest1.PostgresConnector;

/**
 *
 * @author dc982
 */

/**
 * Root resource (exposed at "auth" path)
 */
@Path("auth")
public class Authentication {
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public boolean auth(@QueryParam("username") String username,
            @QueryParam("password") String password){
        
        byte[] passwordhash = Hashing.hash(password);
        
        String passwordHashRes = "";
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */       
        PostgresConnector pc = new PostgresConnector("localhost", "hospitalevora", "postgres", "admin");
        
        try {
            pc.connect();
            Statement stmt = pc.getStatement();
            ResultSet res = stmt.executeQuery("SELECT password FROM users WHERE username='"+username+"';");
            while(res.next()){
                passwordHashRes = res.getString("password");
            }
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        return passwordHashRes.equals(Arrays.toString(passwordhash));
    }
}
