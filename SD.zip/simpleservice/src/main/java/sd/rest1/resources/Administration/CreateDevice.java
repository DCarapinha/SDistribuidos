package sd.rest1.resources.Administration;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import sd.rest1.PostgresConnector;

/**
 * @author dc982
 */

/**
 * TODO: 
 *      CHANGE THE WAY INFORMATION IS SENT
 *      CURRENT:    CreateDevice -> Database
 *      FINAL:      CreateDevice -> Broker -> Server -> Database
 */


 /**
 * Root resource (exposed at "/create/device" path)
 */
@Path("/create/device")
public class CreateDevice {
    /**
     * Method handling HTTP GET requests. The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @return String that will be returned as a text/plain response.
     */
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String CreateDevice() {
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - db name
         * @param 3 - user
         * @param 4 - password
         */
        PostgresConnector pc = new PostgresConnector("localhost", "hospitalevora", "postgres", "admin");
        try {
            pc.connect();
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        Statement stmt = pc.getStatement();
        try {
            /**
             * Creates a new device with a sequencial "id", random "temperatura" (min: 0 , max: 40) and "humidade" (min: 0, max: 10),
             * and "timestamp" with the current time
             */
            stmt.executeUpdate("INSERT INTO device (id, temperatura, humidade, timestamp) VALUES (DEFAULT,'"+
                    String.format(java.util.Locale.US,"%.2f", Math.random()*41)+
                    "','"+
                    String.format(java.util.Locale.US,"%.2f", Math.random()*11)+
                    "','"+
                    new Timestamp(System.currentTimeMillis())+
                    "');"
            );
            
            /**
             * DISPLAYS ALL THE ENTRIES FOR THE TABLE "device"
            */
            /*ResultSet res = stmt.executeQuery("SELECT * FROM device;");
            ResultSetMetaData rsmd = res.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            while (res.next()) {
                for (int i = 1; i <= columnsNumber; i++) {
                    if (i > 1) System.out.print(",  ");
                    String columnValue = res.getString(i);
                    System.out.print(columnValue);
                }
                System.out.println("");
            }*/
        } catch (SQLException ex) {
            System.out.println("Exception: " + ex);
        }
        
        pc.disconnect();
        return "Device Created!";
    }   
}
