package sd.rest1.resources.Administration;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import sd.rest1.PostgresConnector;

/**
 * @author dc982
 */

/**
 * TODO: 
 *      CHANGE THE WAY INFORMATION IS SENT
 *      CURRENT:    CreateDevice -> Database
 *      FINAL:      CreateDevice -> Broker -> Server -> Database
 */


 /**
 * Root resource (exposed at "/create/device" path)
 */
@Path("create/device")
public class CreateDevice {
    /**
     * Method handling HTTP GET requests.The returned object will be sent
 to the client as "text/plain" media type.
     *
     * @param room      - Room where the device is installed
     * @param floor     - Floor where the device is installed
     * @param building  - Building where the device is installed
     * @param service   - Service where the device is installed
     * @return String that will be returned as a text/plain response.
     */
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String CreateDevice(@QueryParam("room") String room,
            @QueryParam("floor") String floor,
            @QueryParam("building") String building,
            @QueryParam("service") String service) {
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - db name
         * @param 3 - user
         * @param 4 - password
         */
        PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        try {
            pc.connect();
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        Statement stmt = pc.getStatement();
        try {
            /**
             * Creates a new device with a sequential "id", random "temperatura" (min: 0 , max: 40) and "humidade" (min: 0, max: 10),
             * and "timestamp" with the current time
             */
            stmt.executeUpdate("INSERT INTO device (id, temperatura, humidade, timestamp) VALUES (DEFAULT,"+
                    "RANDOM() * (31-20)+20, " +
                    "RANDOM() * (0.6-0.4)+0.4, '"+
                    new Timestamp(System.currentTimeMillis()) + "');");
            /**
             * Get the last inserted id
             */
            ResultSet res = stmt.executeQuery("SELECT MAX(id) AS id FROM device;");
            res.next();
            int last_id = res.getInt("id");
            /**
             * Create a new entry that associates a new device with its location
             */
            stmt.executeUpdate("INSERT INTO location (id, service, floor, building, room) VALUES('" +
                    last_id + "','" +
                    service + "','" +
                    floor + "','" +
                    building + "','" +
                    room + "');");
        } catch (SQLException ex) {
            System.out.println("Exception: " + ex);
        }
        
        pc.disconnect();
        return "Device Created!";
    }   
}
