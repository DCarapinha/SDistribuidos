package sd.rest1.resources.Administration;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import sd.rest1.PostgresConnector;

/**
 * Root resource (exposed at "device" path)
 */
@Path("device")
public class DeviceManagement {
    /**
     * Method handling the creation of a new IOT device. 
     * 
     * @param room      - Room where the device is installed
     * @param floor     - Floor where the device is installed
     * @param building  - Building where the device is installed
     * @param service   - Service where the device is installed
     * @return String that will be returned as a text/plain response.
     */
    @GET @Path("/create")
    @Produces(MediaType.TEXT_PLAIN)
    public String CreateDevice(@QueryParam("room") String room,
            @QueryParam("floor") String floor,
            @QueryParam("building") String building,
            @QueryParam("service") String service) {
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */
        PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        try {
            pc.connect();
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        Statement stmt = pc.getStatement();
        try {
            /**
             * Creates a new device with a sequential "id", random "temperature" (min: 0 , max: 40) and "humidity" (min: 0, max: 10),
             * and "timestamp" with the current time
             */
            stmt.executeUpdate("INSERT INTO device (id, temperatura, humidade, timestamp) VALUES (DEFAULT,"+
                    "RANDOM() * (31-20)+20, " +
                    "RANDOM() * (0.6-0.4)+0.4, '"+
                    new Timestamp(System.currentTimeMillis()) + "');");
            /**
             * Get the last inserted id
             */
            ResultSet res = stmt.executeQuery("SELECT MAX(id) AS id FROM device;");
            res.next();
            int last_id = res.getInt("id");
            /**
             * Create a new entry that associates a new device with its location
             */
            stmt.executeUpdate("INSERT INTO location (id, service, floor, building, room) VALUES('" +
                    last_id + "','" +
                    service + "','" +
                    floor + "','" +
                    building + "','" +
                    room + "');");
        } catch (SQLException ex) {
            System.out.println("Exception: " + ex);
        }
        pc.disconnect();
        return "Device Created!";
    }

    
    /**
     * Method handling updates to IOT devices.
     * 
     * @param id
     * @param room
     * @param floor
     * @param service
     * @param building
     * @return String that will be returned as a text/plain response.
     */
    @GET @Path("/update")
    @Produces(MediaType.TEXT_PLAIN)
    public String Update(@QueryParam("id") int id, 
            @QueryParam("room") String room,
            @QueryParam("floor") String floor,
            @QueryParam("service") String service,
            @QueryParam("building") String building) {
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - db name
         * @param 3 - user
         * @param 4 - password
         */
        PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        try {
            pc.connect();
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        try {
            
            /**
             * Validate the values that are being updated
             */
            Statement stmt1 = pc.getStatement();
            ResultSet res = stmt1.executeQuery("SELECT * FROM location WHERE id='"+id+"';");
            room = room == null ? res.getString("room") : room;
            floor = floor == null ? res.getString("floor") : floor;
            building = building == null ? res.getString("building") : building;
            service = service == null ? res.getString("service") : service;
            
            
            /**
             * Updates a device with the given parameters
             */
            Statement stmt = pc.getStatement();
            stmt.executeUpdate("UPDATE location SET" + 
                " room=" + room +
                ", floor=" + floor +
                ", service=" + service +
                ", building=" + building+    
                " WHERE id='" + id + "';");
            try {
                Thread.sleep(2000);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return "Updated!";
    }
    
    
    
    /**
     * Method handling the deletion of IOT devices.
     *
     * @param id - Device id to be deleted
     * @return String that will be returned as a text/plain response.
     */
    @GET @Path("/delete")
    @Produces(MediaType.TEXT_PLAIN)
    public String DeleteDevice(@QueryParam("id") int id) {
        return "Deleted!";
    }

}
