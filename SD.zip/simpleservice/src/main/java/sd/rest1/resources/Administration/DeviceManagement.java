package sd.rest1.resources.Administration;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import sd.rest1.PostgresConnector;

/**
 * Root resource (exposed at "device" path)
 */
@Path("device")
public class DeviceManagement {
    /**
     * Method handling the creation of a new IOT device. 
     * 
     * @param room      - Room where the device is installed
     * @param floor     - Floor where the device is installed
     * @param building  - Building where the device is installed
     * @param service   - Service where the device is installed
     * @return String that will be returned as a text/plain response.
     */
    @GET @Path("/create")
    @Produces(MediaType.TEXT_PLAIN)
    public String CreateDevice(@QueryParam("room") String room,
            @QueryParam("floor") String floor,
            @QueryParam("building") String building,
            @QueryParam("service") String service) {
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */
        PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        try {
            pc.connect();
            Statement stmt = pc.getStatement();
            /**
             * Creates a new device with a sequential "id", random "temperature" (min: 0 , max: 40) and "humidity" (min: 0, max: 10),
             * and "timestamp" with the current time
             */
            stmt.executeUpdate("INSERT INTO device (id, temperatura, humidade, timestamp) VALUES (DEFAULT,"+
                    "RANDOM() * (31-20)+20, " +
                    "RANDOM() * (0.6-0.4)+0.4, '"+
                    new Timestamp(System.currentTimeMillis()) + "');");
            /**
             * Get the last inserted id
             */
            ResultSet res = stmt.executeQuery("SELECT MAX(id) AS id FROM device;");
            res.next();
            int last_id = res.getInt("id");
            /**
             * Create a new entry that associates a new device with its location
             */
            stmt.executeUpdate("INSERT INTO location (id, service, floor, building, room) VALUES('" +
                    last_id + "','" +
                    service + "','" +
                    floor + "','" +
                    building + "','" +
                    room + "');");
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        pc.disconnect();
        return "Device Created!";
    }

    
    /**
     * Method handling the listing of IOT devices.
     *
     * @return String that will be returned as a text/plain response.
     */
    @GET @Path("/list")
    @Produces(MediaType.TEXT_PLAIN)
    public String ListDevices() {
        String response = "";
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */
        PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        try {
            pc.connect();
            Statement stmt = pc.getStatement();
            /**
             * Get the last inserted id
             */
            ResultSet res = stmt.executeQuery("SELECT * FROM location ORDER BY id");
            while(res.next()){
                response += String.format(
                          " ------------------------------ \n"
                        + "| id: %-24s |\n"
                        + "| sala: %-22s |\n"
                        + "| andar: %-21s |\n"
                        + "| edificio: %-18s |\n"
                        + "| servico: %-19s |\n",
                        res.getInt("id"), res.getInt("room"), 
                        res.getInt("floor"), res.getInt("building"),
                        res.getString("service"));
            }
            response += " ------------------------------ \n";
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        pc.disconnect();
        return response;
    }

    
    /**
     * Method handling updates to IOT devices.
     * 
     * @param id
     * @param room
     * @param floor
     * @param service
     * @param building
     * @return String that will be returned as a text/plain response.
     */
    @GET @Path("/update")
    @Produces(MediaType.TEXT_PLAIN)
    public String Update(@QueryParam("id") int id, 
            @QueryParam("room") String room,
            @QueryParam("floor") String floor,
            @QueryParam("service") String service,
            @QueryParam("building") String building) {
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - db name
         * @param 3 - user
         * @param 4 - password
         */
        PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        int ret = 0;
        try {
            pc.connect();
            Statement stmt1 = pc.getStatement();
            ResultSet res = stmt1.executeQuery("SELECT * FROM location WHERE id="+id+";");
            /**
             * Validate the values that are being updated
             */
            room = room.equals("null") ? res.getString("room") : room;
            floor = floor.equals("null") ? res.getString("floor") : floor;
            building = building.equals("null") ? res.getString("building") : building;
            service = service.equals("null") ? res.getString("service") : service;
            /**
             * Updates a device with the given parameters
             */
            Statement stmt = pc.getStatement();
            ret = stmt.executeUpdate("UPDATE location SET" + 
                " room=" + room +
                ", floor=" + floor +
                ", service='" + service +
                "', building=" + building +    
                " WHERE id=" + id + ";");
            
            stmt.close();
            stmt1.close();
            pc.disconnect();
            
            
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        if(ret != 0) return "Updated!";
        else return "Not Updated!";
    }
    
    
    
    /**
     * Method handling the deletion of IOT devices.
     *
     * @param id - Device id to be deleted
     * @return String that will be returned as a text/plain response.
     */
    @GET @Path("/delete")
    @Produces(MediaType.TEXT_PLAIN)
    public String DeleteDevice(@QueryParam("id") int id) {
        return "Deleted!";
    }

}
