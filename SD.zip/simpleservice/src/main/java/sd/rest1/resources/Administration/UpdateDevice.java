package sd.rest1.resources.Administration;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import java.sql.ResultSet;

import java.sql.SQLException;
import java.sql.Statement;
import sd.rest1.PostgresConnector;


/**
 * Root resource (exposed at "update/device" path)
 */

@Path("update/device")
public class UpdateDevice {
    /**
     * Method handling HTTP GET requests.The returned object will be sent
     * to the client as "text/plain" media type.
     *
     * @param id
     * @param room
     * @param floor
     * @param service
     * @param building
     * @return String that will be returned as a text/plain response.
     */
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String update(@QueryParam("id") int id, 
            @QueryParam("room") String room,
            @QueryParam("floor") String floor,
            @QueryParam("service") String service,
            @QueryParam("building") String building) {
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - db name
         * @param 3 - user
         * @param 4 - password
         */
        PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        try {
            pc.connect();
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        try {
            
            /**
             * Validate the values that are being updated
             */
            Statement stmt1 = pc.getStatement();
            ResultSet res = stmt1.executeQuery("SELECT * FROM location WHERE id='"+id+"';");
            room = room == null ? res.getString("room") : room;
            floor = floor == null ? res.getString("floor") : floor;
            building = building == null ? res.getString("building") : building;
            service = service == null ? res.getString("service") : service;
            
            
            /**
             * Updates a device with the given parameters
             */
            Statement stmt = pc.getStatement();
            stmt.executeUpdate("UPDATE location SET" + 
                " room=" + room +
                ", floor=" + floor +
                ", service=" + service +
                ", building=" + building+    
                " WHERE id='" + id + "';");
            try {
                Thread.sleep(2000);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return "Updated!";
    }
}