/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sd.rest1;

import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

/**
 *
 * @author dc982
 */
public class DeviceController {
    public static void main(String args[]){
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - dbName
         * @param 3 - user
         * @param 4 - password
         */
        PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        try {
            pc.connect();
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        try {
            /**
             * Updates all devices every 2 seconds
             */
            Statement stmt = pc.getStatement();
            while(true){ // random()*(b-a)+a;
                stmt.executeUpdate("UPDATE device SET temperatura=RANDOM() * (31-20)+20"+
                ", humidade=RANDOM() * (0.6-0.4)+0.4"+
                ", timestamp='"+
                new Timestamp(System.currentTimeMillis())+
                "';");
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}