/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sd.rest1;

import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

/**
 *
 * @author dc982
 */
public class DeviceController {
    public static void main(String args[]){
        /**
         * Connection to a postgres database
         * @param 1 - host
         * @param 2 - db name
         * @param 3 - user
         * @param 4 - password
         */
        PostgresConnector pc = new PostgresConnector("localhost", "hospitalevora", "postgres", "admin");
        try {
            pc.connect();
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
        try {
            /**
             * Updates all devices every 2 seconds
             */
            Statement stmt = pc.getStatement();
            while(true){
                stmt.executeUpdate("UPDATE device SET temperatura=RANDOM() * 41"+
                ", humidade=RANDOM() * 41"+
                ", timestamp='"+
                new Timestamp(System.currentTimeMillis())+
                "';");
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}