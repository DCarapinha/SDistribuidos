package sd.rest1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dc982
 */
public class Client {
    
    private static String IsValidInput(BufferedReader input){
        String buffer = "";
        do{
            try {
                buffer = input.readLine();
                buffer = buffer.equals("") ? "-1" : buffer.replaceAll("\\s+", "").substring(0,1);
                buffer = Character.isDigit(buffer.charAt(0)) ? buffer : "-1";
            } catch (IOException ex) {
                System.out.println("Exception: " + ex);
            }
        }while(!Character.isDigit(buffer.charAt(0)));
        return buffer;
    }
    
    public static void main(String args[]) throws MalformedURLException, ProtocolException, IOException{
        //String targetURL = "http://localhost:8080/create/device?room=1&floor=2&building=3&service=urgencia";
        //String targetURL = "http://localhost:8080/update?id=1&floor=1&room=2&building=3&service=urgencia";
        //String targetURL = "http://localhost:8080/check/service?room=0&floor=0&building=9&service=urgencia&startDate=2024-12-01";
        String content = "";
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        int op = -1;
        while(op != 0){
            int room = 0, floor = 0, building = 0;
            String service = "", startDate = "", endDate = "", buffer = "", targetURL = "http://localhost:8080/";
            System.out.println(" ------------------------------ ");
            System.out.println("|                              |");
            System.out.println("| 0 - Sair                     |");
            System.out.println("| 1 - Consultar Sala           |");
            System.out.println("| 2 - Consultar Andar          |");
            System.out.println("| 3 - Consultar Edificio       |");
            System.out.println("| 4 - Consultar Servico        |");
            System.out.println("|                              |");
            System.out.println(" ------------------------------ ");
            op = Integer.parseInt(IsValidInput(input));
            switch(op){
                case 1:
                    System.out.println("-------------------------------");
                    System.out.println("\n  Numero da sala:              ");
                    System.out.print("\t");
                    buffer = IsValidInput(input);
                    room = Integer.parseInt(buffer);
                    System.out.println("\n  Numero do andar:");
                    System.out.print("\t");
                    floor = Integer.parseInt(IsValidInput(input));
                    System.out.println("\n  Numero do edificio:");
                    System.out.print("\t");
                    building = Integer.parseInt(IsValidInput(input));
                    System.out.println("\n  Data inicial (yyyy-mm-dd):");
                    System.out.print("\t");
                    startDate = input.readLine();
                    startDate = startDate.equals("") ? null : startDate;
                    System.out.println("\n  Data final (yyyy-mm-dd):");
                    System.out.print("\t");
                    endDate = input.readLine();
                    endDate = endDate.equals("") ? null : endDate;
                    System.out.println("\n------------------------------- ");
                    targetURL += "check/room?room="+room+"&floor="+floor+"&building="+building+
                                 "&startDate="+startDate+"&endDate="+endDate;
                    content = GETRequest(targetURL);
                    break;
                case 2:
                    System.out.println("-------------------------------");
                    System.out.println("\n  Numero do andar:");
                    System.out.print("\t");
                    floor = Integer.parseInt(IsValidInput(input));
                    System.out.println("\n  Numero do edificio:");
                    System.out.print("\t");
                    building = Integer.parseInt(IsValidInput(input));
                    System.out.println("\n  Nome do servico:");
                    System.out.print("\t");
                    service = input.readLine();
                    System.out.println("\n  Data inicial (yyyy-mm-dd):");
                    System.out.print("\t");
                    startDate = input.readLine();
                    startDate = startDate.equals("") ? null : startDate;
                    System.out.println("\n  Data final (yyyy-mm-dd):");
                    System.out.print("\t");
                    endDate = input.readLine();
                    endDate = endDate.equals("") ? null : endDate;
                    System.out.println("\n------------------------------- ");
                    targetURL += "check/floor?floor="+floor+"&building="+building+
                                 "&service="+service+"&startDate="+startDate+"&endDate="+endDate;
                    content = GETRequest(targetURL);
                    break;
                case 3:
                    System.out.println("-------------------------------");
                    System.out.println("\n  Numero do edificio:");
                    System.out.print("\t");
                    building = Integer.parseInt(IsValidInput(input));
                    System.out.println("\n  Nome do servico:");
                    System.out.print("\t");
                    service = input.readLine();
                    System.out.println("\n  Data inicial (yyyy-mm-dd):");
                    System.out.print("\t");
                    startDate = input.readLine();
                    startDate = startDate.equals("") ? null : startDate;
                    System.out.println("\n  Data final (yyyy-mm-dd):");
                    System.out.print("\t");
                    endDate = input.readLine();
                    endDate = endDate.equals("") ? null : endDate;
                    System.out.println("\n------------------------------- ");
                    targetURL += "check/building/building="+building+"&service="+service+
                                 "&startDate="+startDate+"&endDate="+endDate;
                    content = GETRequest(targetURL);
                    break;
                case 4:
                    System.out.println("-------------------------------");
                    System.out.println("\n  Nome do servico:");
                    System.out.print("\t");
                    service = input.readLine();
                    System.out.println("\n  Data inicial (yyyy-mm-dd):");
                    System.out.print("\t");
                    startDate = input.readLine();
                    startDate = startDate.equals("") ? null : startDate;
                    System.out.println("\n  Data final (yyyy-mm-dd):");
                    System.out.print("\t");
                    endDate = input.readLine();
                    endDate = endDate.equals("") ? null : endDate;
                    System.out.println("\n------------------------------- ");
                    targetURL += "check/service/service="+service+
                                 "&startDate="+startDate+"&endDate="+endDate;
                    content = GETRequest(targetURL);
                    break;
                case 0:
                    System.exit(0);
                    break;
                default:
                    System.out.println("\n ");
                    break;
            }
            System.out.println(content);
        }
    }
    
    public static String GETRequest(String targetURL){
        URL url;
        StringBuilder content = new StringBuilder();
        try {
            url = new URL(targetURL);
        
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");

            con.setRequestProperty("Content-Type", "application/json");

            int status = con.getResponseCode();
            try (BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()))) {
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    content.append(inputLine).append("\n");
                }   
            }
            con.disconnect();
        } catch (IOException ex) {
            System.out.println(ex);
        }
        return content.toString();
    }
}
