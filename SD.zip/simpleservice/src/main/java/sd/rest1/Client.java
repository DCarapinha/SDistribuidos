package sd.rest1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

/**
 *
 * @author dc982
 */
public class Client {
    public static void main(String args[]) throws MalformedURLException, ProtocolException, IOException{
        String targetURL = "http://localhost:8080/create/device?room=1&floor=2&building=3&service=urgencia";
        //String targetURL = "http://localhost:8080/update?id=1&floor=1&room=2&building=3&service=urgencia";
        String content = GETRequest(targetURL);
        System.out.println(content);
    }
    public static String GETRequest(String targetURL){
        URL url;
        StringBuilder content = new StringBuilder();
        try {
            url = new URL(targetURL);
        
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");

            con.setRequestProperty("Content-Type", "application/json");

            int status = con.getResponseCode();
            try (BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()))) {
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        content.append(inputLine);
                    }   
                }
                con.disconnect();
        } catch (IOException ex) {
            System.out.println(ex);
        }
        return content.toString();
    }
}
