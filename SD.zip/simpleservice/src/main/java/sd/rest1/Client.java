package sd.rest1;

import java.io.BufferedReader;
import java.io.Console;
import java.io.IOException;
import java.io.InputStreamReader;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.sql.Statement;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import sd.rest1.resources.Security.Hashing;

/**
 *
 * @author dc982
 */
public class Client {
    
    public static void main(String args[]) throws MalformedURLException, ProtocolException, IOException, InterruptedException{        
        /*PostgresConnector pc = new PostgresConnector("localhost", "HospitalEvora", "postgres", "admin");
        try {
            pc.connect();
            Statement stmt = pc.getStatement();
            byte[] passhashbytes = Hashing.hash("admin");
            stmt.executeUpdate("INSERT INTO users VALUES(DEFAULT, 'admin', '"+Arrays.toString(passhashbytes)+"');");
        } catch (Exception ex) {
            Logger.getLogger(Client.class.getName()).log(Level.SEVERE, null, ex);
        }*/
        
        String content = "";
        int op = -1;
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        Console console = System.console();
  
        if (console == null) {
            System.out.println("No console available"); 
            System.exit(1);
        }
        clearScreen();
        
        System.out.print("Username: ");
        String username = input.readLine();
        System.out.print("Password: ");
        char[] charPassword = console.readPassword();
        String password = new String(charPassword);
        
        System.out.print("\nLoading");
        for(int i = 0; i < 3; i++){
            System.out.print(".");
            Thread.sleep(500);
        }
        
        String authURL= "http://localhost:8080/auth?username="+username+"&password="+password;
        if( !GETRequest(authURL).equals("true\n") ){
            System.out.println("\nUtilizador não tem permissão!");
            System.exit(1);
        }
        System.out.println("\nUtilizador Autorizado!");
        Thread.sleep(1000);
        clearScreen();
        
        while(op != 0){
            String room = "", floor = "", building = "", id = "";
            String service = "", startDate = "", endDate = "", buffer = "", targetURL = "http://localhost:8080/";
            
            System.out.println(" ------------------------------ ");
            System.out.println("|                              |");
            System.out.println("| 1 - Gerir dispositivos       |");
            System.out.println("| 2 - Consultar métricas       |");
            System.out.println("| 0 - Sair                     |");
            System.out.println("|                              |");
            System.out.println(" ------------------------------ ");
            op = Integer.parseInt(IsValidInput(input));
            clearScreen();
            // Gestao de dispositivos
            if(op == 1){
                System.out.println(" ------------------------------ ");
                System.out.println("|                              |");
                System.out.println("| 1 - Criar dispositivo        |");
                System.out.println("| 2 - Listar dispositivos      |");
                System.out.println("| 3 - Atualizar informações    |");
                System.out.println("| 4 - Eliminar dispositivo     |");
                System.out.println("| 0 - Sair                     |");
                System.out.println("|                              |");
                System.out.println(" ------------------------------ ");
                op = Integer.parseInt(IsValidInput(input));
                clearScreen();
                switch(op){
                    case 1:
                        System.out.println("-------------------------------");
                        System.out.println("\n  Numero da sala:");
                        System.out.print("\t");
                        room = IsValidInput(input);
                        System.out.println("\n  Numero do andar:");
                        System.out.print("\t");
                        floor = IsValidInput(input);
                        System.out.println("\n  Numero do edificio:");
                        System.out.print("\t");
                        building = IsValidInput(input);
                        System.out.println("\n  Nome do servico:");
                        System.out.print("\t");
                        service = input.readLine();
                        System.out.println("\n------------------------------- ");
                        targetURL += "device/create?room="+room+"&floor="+floor+
                                "&building="+building+"&service="+service;
                        content = GETRequest(targetURL);
                        break;
                    case 2:
                        targetURL += "device/list";
                        content = GETRequest(targetURL);
                        break;
                    case 3:
                        System.out.println("-------------------------------");
                        System.out.println("\n  Numero do dispositivo:");
                        System.out.print("\t");
                        id = IsValidInput(input);
                        System.out.println("\n  Numero da sala:");
                        System.out.print("\t");
                        buffer = input.readLine();
                        room = buffer.equals("") ? "null" : IsValidInputWithReadInput(input, buffer);
                        System.out.println("\n  Numero do andar:");
                        System.out.print("\t");
                        buffer = input.readLine();
                        floor = buffer.equals("") ? "null" : IsValidInputWithReadInput(input, buffer);
                        System.out.println("\n  Numero do edificio:");
                        System.out.print("\t");
                        buffer = input.readLine();
                        building = buffer.equals("") ? "null" : IsValidInputWithReadInput(input, buffer);
                        System.out.println("\n  Nome do servico:");
                        System.out.print("\t");
                        service = input.readLine();
                        System.out.println("\n------------------------------- ");
                        targetURL += "device/update?id="+id+"&room="+room+"&floor="+floor+
                                "&building="+building+"&service="+service;
                        content = GETRequest(targetURL);
                        break;
                    case 4:
                        System.out.println("-------------------------------");
                        System.out.println("\n  Numero do dispositivo:");
                        System.out.print("\t");
                        id = IsValidInput(input);
                        System.out.println("\n------------------------------- ");
                        targetURL += "device/delete?id="+id;
                        content = GETRequest(targetURL);
                        break;
                    case 0:
                        System.exit(0);
                        break;
                    default:
                        System.out.println("\n ");
                        break;
                }
            }
            // Consultar metricas
            else if(op == 2){
                System.out.println(" ------------------------------ ");
                System.out.println("|                              |");
                System.out.println("| 1 - Consultar Sala           |");
                System.out.println("| 2 - Consultar Andar          |");
                System.out.println("| 3 - Consultar Edificio       |");
                System.out.println("| 4 - Consultar Servico        |");
                System.out.println("| 0 - Sair                     |");
                System.out.println("|                              |");
                System.out.println(" ------------------------------ ");
                op = Integer.parseInt(IsValidInput(input));
                switch(op){
                    case 1:
                        System.out.println("-------------------------------");
                        System.out.println("\n  Numero da sala:");
                        System.out.print("\t");
                        room = IsValidInput(input);
                        System.out.println("\n  Numero do andar:");
                        System.out.print("\t");
                        floor = IsValidInput(input);
                        System.out.println("\n  Numero do edificio:");
                        System.out.print("\t");
                        building = IsValidInput(input);
                        System.out.println("\n  Data inicial (yyyy-mm-dd):");
                        System.out.print("\t");
                        startDate = input.readLine();
                        startDate = startDate.equals("") ? null : startDate;
                        System.out.println("\n  Data final (yyyy-mm-dd):");
                        System.out.print("\t");
                        endDate = input.readLine();
                        endDate = endDate.equals("") ? null : endDate;
                        System.out.println("\n------------------------------- ");
                        targetURL += "check/room?room="+room+"&floor="+floor+"&building="+building+
                                     "&startDate="+startDate+"&endDate="+endDate;
                        content = GETRequest(targetURL);
                        break;
                    case 2:
                        System.out.println("-------------------------------");
                        System.out.println("\n  Numero do andar:");
                        System.out.print("\t");
                        floor = IsValidInput(input);
                        System.out.println("\n  Numero do edificio:");
                        System.out.print("\t");
                        building = IsValidInput(input);
                        System.out.println("\n  Nome do servico:");
                        System.out.print("\t");
                        service = input.readLine();
                        System.out.println("\n  Data inicial (yyyy-mm-dd):");
                        System.out.print("\t");
                        startDate = input.readLine();
                        startDate = startDate.equals("") ? null : startDate;
                        System.out.println("\n  Data final (yyyy-mm-dd):");
                        System.out.print("\t");
                        endDate = input.readLine();
                        endDate = endDate.equals("") ? null : endDate;
                        System.out.println("\n------------------------------- ");
                        targetURL += "check/floor?floor="+floor+"&building="+building+
                                     "&service="+service+"&startDate="+startDate+"&endDate="+endDate;
                        content = GETRequest(targetURL);
                        break;
                    case 3:
                        System.out.println("-------------------------------");
                        System.out.println("\n  Numero do edificio:");
                        System.out.print("\t");
                        building = IsValidInput(input);
                        System.out.println("\n  Nome do servico:");
                        System.out.print("\t");
                        service = input.readLine();
                        System.out.println("\n  Data inicial (yyyy-mm-dd):");
                        System.out.print("\t");
                        startDate = input.readLine();
                        startDate = startDate.equals("") ? null : startDate;
                        System.out.println("\n  Data final (yyyy-mm-dd):");
                        System.out.print("\t");
                        endDate = input.readLine();
                        endDate = endDate.equals("") ? null : endDate;
                        System.out.println("\n------------------------------- ");
                        targetURL += "check/building/building="+building+"&service="+service+
                                     "&startDate="+startDate+"&endDate="+endDate;
                        content = GETRequest(targetURL);
                        break;
                    case 4:
                        System.out.println("-------------------------------");
                        System.out.println("\n  Nome do servico:");
                        System.out.print("\t");
                        service = input.readLine();
                        System.out.println("\n  Data inicial (yyyy-mm-dd):");
                        System.out.print("\t");
                        startDate = input.readLine();
                        startDate = startDate.equals("") ? null : startDate;
                        System.out.println("\n  Data final (yyyy-mm-dd):");
                        System.out.print("\t");
                        endDate = input.readLine();
                        endDate = endDate.equals("") ? null : endDate;
                        System.out.println("\n------------------------------- ");
                        targetURL += "check/service/service="+service+
                                     "&startDate="+startDate+"&endDate="+endDate;
                        content = GETRequest(targetURL);
                        break;
                    case 0:
                        System.exit(0);
                        break;
                    default:
                        System.out.println("\n ");
                        break;
                }
            }
            
            
            System.out.println(content);
        }
    }
    
    public static void clearScreen() {  
        System.out.print("\033[H\033[2J");  
        System.out.flush();  
    }
    
    private static String IsValidInput(BufferedReader input){
        String buffer = "";
        do{
            try {
                buffer = input.readLine();
                buffer = buffer.equals("") ? "-1" : buffer.replaceAll("\\s+", "").substring(0,1);
                buffer = Character.isDigit(buffer.charAt(0)) ? buffer : "-1";
            } catch (Exception ex) {
                System.out.println("Exception: " + ex);
            }
        }while(!Character.isDigit(buffer.charAt(0)));
        return buffer;
    }
    
    private static String IsValidInputWithReadInput(BufferedReader input, String currentInput){
        String buffer = currentInput;
        while(!Character.isDigit(buffer.charAt(0))){
            try {
                buffer = input.readLine();
                buffer = buffer.equals("") ? "-1" : buffer.replaceAll("\\s+", "").substring(0,1);
                buffer = Character.isDigit(buffer.charAt(0)) ? buffer : "-1";
            } catch (Exception ex) {
                System.out.println("Exception: " + ex);
            }
        }
        return buffer;
    }

    private static String GETRequest(String targetURL){
        URL url;
        StringBuilder content = new StringBuilder();
        try {
            url = new URL(targetURL);
        
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");

            con.setRequestProperty("Content-Type", "application/json");

            int status = con.getResponseCode();
            try (BufferedReader in = new BufferedReader(
                new InputStreamReader(con.getInputStream()))) {
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    content.append(inputLine).append("\n");
                }   
            }
            con.disconnect();
        } catch (IOException ex) {
            System.out.println(ex);
        }
        return content.toString();
    }
}