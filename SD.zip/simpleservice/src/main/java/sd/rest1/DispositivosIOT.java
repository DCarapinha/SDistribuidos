package sd.rest1;

import java.io.IOException;

/** Mensagens para o broker
    ○ Identificador único do dispositivo (id);
    ○ Temperatura registada;
    ○ Humidade registada;
    ○ Timestamp (data e hora do envio).
 */

/**
 * DispositivosIOT class.
 *
 */
public class DispositivosIOT {
    // Base URI the Grizzly HTTP server will listen on
    public static final String BASE_URI = "http://localhost:8080/";

    /**
     * Main method.
     * 
     * @param args
     * @throws IOException
     */
    public static void main(String[] args){
        
    }
}
