package sd.rest1;

import java.io.IOException;

/** Mensagens para o broker
    ○ Identificador único do dispositivo (id);
    ○ Temperatura registada;
    ○ Humidade registada;
    ○ Timestamp (data e hora do envio).
 */

/**
 * Device class.
 *
 */
public class Device {
    private int id;
    public Device(int device_id){
        id = device_id;
    }
    
    public int getDeviceId(){
        return id;
    }
    
    /**
     * Main method.
     * 
     * @param args
     * @throws IOException
     */
    public static void main(String[] args){
        
    }
}
